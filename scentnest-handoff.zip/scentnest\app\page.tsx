import Image from "next/image";
import Link from "next/link";
import { getProducts } from "@/lib/products";
import { Hero } from "@/components/home/hero";
import { Signatures } from "@/components/home/signatures";
import { Finder } from "@/components/home/finder";
import { Marquee } from "@/components/marquee";
import { ProductCard } from "@/components/product-card";
import { FaqList } from "@/components/faq-list";
import { faqs } from "@/lib/faqs";
import { Button } from "@/components/button";
import { ImageReveal, Parallax, Reveal, SplitText } from "@/components/motion";
import { BottleMark } from "@/components/logo";
import { whatsappLink } from "@/lib/site";

const houses = ["Dior", "Tom Ford", "Louis Vuitton", "Yves Saint Laurent", "Armani", "Jean Paul Gaultier", "Montblanc", "Lancôme", "Valentino", "Carolina Herrera", "Viktor & Rolf", "Azzaro", "Ralph Lauren"];

const steps = [
  { t: "Choose your scent", d: "Pick a signature and a size: 30, 50 or 100 ml." },
  { t: "We call to confirm", d: "A quick call or WhatsApp to check your order and address." },
  { t: "Bottled for you", d: "Filled, sealed and packed with care." },
  { t: "Pay at your door", d: "Delivered across Lebanon. Cash on delivery." },
];

export default async function Home() {
  const products = await getProducts();
  const featured = products.filter((p) => p.featured);
  const bestsellers = products.filter((p) => p.bestseller).slice(0, 4);
  const him = products.find((p) => p.slug === "royal-oud") ?? products[0];
  const her = products.find((p) => p.slug === "liquid-gold") ?? products[1];

  return (
    <>
      <Hero products={featured.length ? featured : products.slice(0, 6)} />

      <section className="border-y border-white/10 py-8" aria-label="Inspired by">
        <Marquee items={houses.map((h) => `Inspired by ${h}`)} className="font-serif text-3xl italic text-bone/80 sm:text-5xl" />
      </section>

      <Signatures products={featured.length ? featured : products.slice(0, 8)} />

      {/* For him / for her */}
      <section className="container-x py-28 sm:py-36">
        <div className="mb-14 max-w-2xl">
          <p className="eyebrow">Shop by wearer</p>
          <h2 className="display mt-4 text-5xl sm:text-7xl">
            <SplitText text={"For him. For her.\n*For you.*"} />
          </h2>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {[
            { href: "/shop?for=him", label: "For him", sub: "Woods, spice, oud and fresh citrus.", p: him },
            { href: "/shop?for=her", label: "For her", sub: "Florals, vanilla, coffee and musk.", p: her },
          ].map((c, i) => (
            <Reveal key={c.href} delay={i * 0.12}>
              <Link href={c.href} className="group relative block overflow-hidden rounded-[28px] bg-bone">
                <ImageReveal className="aspect-[4/5] sm:aspect-[5/4]" delay={i * 0.12}>
                  <Image src={c.p.image} alt={c.label} fill sizes="(min-width:768px) 50vw, 100vw" className="object-cover mix-blend-multiply transition-transform duration-[1.6s] ease-luxe group-hover:scale-105" />
                </ImageReveal>
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between bg-gradient-to-t from-ink/90 via-ink/40 to-transparent p-8 pt-24">
                  <div>
                    <p className="display text-5xl text-bone">{c.label}</p>
                    <p className="mt-2 text-sm text-bone/70">{c.sub}</p>
                  </div>
                  <span className="flex h-12 w-12 items-center justify-center rounded-full border border-bone/30 text-bone transition-all duration-700 ease-luxe group-hover:rotate-[-45deg] group-hover:border-gold group-hover:bg-gold group-hover:text-ink">→</span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      <Finder />

      {/* Bestsellers */}
      <section className="container-x py-28 sm:py-36">
        <div className="mb-14 flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="eyebrow">Most loved</p>
            <h2 className="display mt-4 text-5xl sm:text-7xl">
              <SplitText text={"The *bestsellers.*"} />
            </h2>
          </div>
          <Button href="/shop" variant="outline">Shop all {products.length}</Button>
        </div>
        <div className="grid gap-x-6 gap-y-14 sm:grid-cols-2 lg:grid-cols-4">
          {bestsellers.map((p, i) => (
            <Reveal key={p.slug} delay={i * 0.08}>
              <ProductCard product={p} index={i} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* Manifesto */}
      <section className="relative overflow-hidden border-y border-white/10 bg-bone py-32 text-ink sm:py-44">
        <Parallax offset={60} className="pointer-events-none absolute -right-20 top-10 text-ink/[0.05]">
          <BottleMark className="h-[70vh] w-auto" strokeWidth={0.6} />
        </Parallax>
        <div className="container-x relative">
          <p className="eyebrow !text-ink/50">Our philosophy</p>
          <p className="display mt-8 max-w-5xl text-[9vw] leading-[1] sm:text-6xl lg:text-[88px]">
            <SplitText text={"Luxury shouldn't be\nkept behind *glass.*"} stagger={0.06} />
          </p>
          <Reveal delay={0.3}>
            <div className="mt-14 grid max-w-4xl gap-10 sm:grid-cols-3">
              {[
                ["Iconic character", "Every blend is built around the soul of a scent you already love."],
                ["Made to last", "Rich in perfume oil for a trail that stays with you."],
                ["Honest price", "The feeling of a designer bottle, without the designer markup."],
              ].map(([t, d]) => (
                <div key={t} className="border-t border-ink/15 pt-5">
                  <p className="font-serif text-2xl">{t}</p>
                  <p className="mt-2 text-sm leading-relaxed text-ink/60">{d}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* How it works */}
      <section className="container-x py-28 sm:py-36">
        <div className="grid gap-16 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <p className="eyebrow">How it works</p>
            <h2 className="display mt-4 text-5xl sm:text-6xl">
              <SplitText text={"Simple, start\nto *finish.*"} />
            </h2>
          </div>
          <ol className="grid gap-px overflow-hidden rounded-[28px] border border-white/10 bg-white/10 sm:grid-cols-2 lg:col-span-8">
            {steps.map((s, i) => (
              <Reveal as="li" key={s.t} delay={i * 0.08} className="group bg-ink p-8 transition-colors duration-700 hover:bg-ink-800 sm:p-10">
                <span className="font-serif text-5xl italic text-gold/80 transition-transform duration-700 group-hover:translate-x-1">0{i + 1}</span>
                <p className="mt-8 font-serif text-3xl">{s.t}</p>
                <p className="mt-3 text-mist">{s.d}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      {/* FAQ */}
      <section className="container-x pb-28 sm:pb-36">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <p className="eyebrow">Questions</p>
            <h2 className="display mt-4 text-5xl sm:text-6xl">
              <SplitText text={"Before you\n*order.*"} />
            </h2>
            <Link href="/faq" className="link-underline mt-8 inline-block text-sm text-gold">All questions →</Link>
          </div>
          <div className="lg:col-span-8">
            <FaqList items={faqs.slice(0, 4)} />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container-x pb-28">
        <Reveal>
          <div className="relative overflow-hidden rounded-[36px] border border-white/10 bg-gradient-to-br from-ink-700 via-ink-800 to-ink px-8 py-20 text-center sm:px-16 sm:py-28">
            <div className="pointer-events-none absolute left-1/2 top-0 h-64 w-[60%] -translate-x-1/2 rounded-full bg-gold/15 blur-[100px]" />
            <p className="eyebrow relative">Not sure yet?</p>
            <p className="display relative mx-auto mt-6 max-w-3xl text-5xl sm:text-7xl">
              Tell us a scent you love. <span className="gold-text italic">We&apos;ll find its match.</span>
            </p>
            <div className="relative mt-10 flex flex-wrap justify-center gap-4">
              <Button href={whatsappLink("Hi ScentNest! Can you help me find a scent?")} external>Ask on WhatsApp</Button>
              <Button href="/shop" variant="outline">Browse everything</Button>
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
