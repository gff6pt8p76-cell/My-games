"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { CartItem } from "./types";

type CartState = {
  items: CartItem[];
  count: number;
  open: boolean;
  setOpen: (v: boolean) => void;
  add: (item: CartItem) => void;
  update: (slug: string, ml: number, qty: number) => void;
  remove: (slug: string, ml: number) => void;
  clear: () => void;
};

const CartContext = createContext<CartState | null>(null);
const KEY = "scentnest.bag.v1";

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [open, setOpen] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setItems(JSON.parse(raw));
    } catch {}
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(items));
    } catch {}
  }, [items, ready]);

  const add = useCallback((item: CartItem) => {
    setItems((prev) => {
      const i = prev.findIndex((p) => p.slug === item.slug && p.ml === item.ml);
      if (i === -1) return [...prev, item];
      const next = [...prev];
      next[i] = { ...next[i], qty: Math.min(10, next[i].qty + item.qty) };
      return next;
    });
    setOpen(true);
  }, []);

  const update = useCallback((slug: string, ml: number, qty: number) => {
    setItems((prev) =>
      qty <= 0
        ? prev.filter((p) => !(p.slug === slug && p.ml === ml))
        : prev.map((p) => (p.slug === slug && p.ml === ml ? { ...p, qty: Math.min(10, qty) } : p)),
    );
  }, []);

  const remove = useCallback((slug: string, ml: number) => {
    setItems((prev) => prev.filter((p) => !(p.slug === slug && p.ml === ml)));
  }, []);

  const clear = useCallback(() => setItems([]), []);

  const value = useMemo(
    () => ({ items, count: items.reduce((n, i) => n + i.qty, 0), open, setOpen, add, update, remove, clear }),
    [items, open, add, update, remove, clear],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside CartProvider");
  return ctx;
}
