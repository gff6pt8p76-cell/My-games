"use client";

import { AnimatePresence, LayoutGroup, motion } from "framer-motion";
import { useMemo, useState } from "react";
import clsx from "clsx";
import type { Family, Gender } from "@/lib/types";
import { useCatalog } from "../providers";
import { ProductCard } from "../product-card";
import { EASE, Reveal, SplitText } from "../motion";

const moods: { value: Family[]; label: string; hint: string }[] = [
  { value: ["fresh"], label: "Fresh", hint: "Citrus, sea air, clean musk" },
  { value: ["floral"], label: "Floral", hint: "Rose, jasmine, white flowers" },
  { value: ["gourmand"], label: "Sweet", hint: "Vanilla, toffee, coffee" },
  { value: ["woody", "oriental", "spicy"], label: "Deep", hint: "Oud, spice, tobacco, woods" },
];
const who: { value: Gender | "all"; label: string }[] = [
  { value: "all", label: "Anyone" },
  { value: "him", label: "Him" },
  { value: "her", label: "Her" },
];

/** A two-question scent finder that filters the catalog live. */
export function Finder() {
  const catalog = useCatalog();
  const [mood, setMood] = useState(2);
  const [g, setG] = useState<Gender | "all">("all");

  const matches = useMemo(() => {
    const fam = moods[mood].value;
    return catalog
      .filter((p) => fam.includes(p.family))
      .filter((p) => g === "all" || p.gender === g || p.gender === "unisex")
      .sort((a, b) => Number(b.bestseller) - Number(a.bestseller))
      .slice(0, 3);
  }, [catalog, mood, g]);

  return (
    <section id="finder" className="relative scroll-mt-24 border-y border-white/10 bg-ink-800 py-28 sm:py-36">
      <div className="container-x grid gap-16 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="eyebrow">Scent finder</p>
          <h2 className="display mt-4 text-5xl sm:text-7xl">
            <SplitText text={"Find your\n*signature.*"} />
          </h2>
          <Reveal delay={0.2}>
            <p className="mt-6 max-w-sm text-mist">Two quick choices. We&apos;ll match you with the scents that fit.</p>
          </Reveal>

          <LayoutGroup id="finder">
            <Reveal delay={0.3} className="mt-12">
              <p className="eyebrow mb-4">01 · What draws you in?</p>
              <div className="grid grid-cols-2 gap-3">
                {moods.map((m, i) => (
                  <button
                    key={m.label}
                    onClick={() => setMood(i)}
                    className={clsx("relative rounded-2xl border px-5 py-4 text-left transition-colors duration-500", i === mood ? "border-gold" : "border-white/10 hover:border-white/30")}
                  >
                    {i === mood && <motion.span layoutId="mood" className="absolute inset-0 rounded-2xl bg-gold/10" transition={{ type: "spring", stiffness: 300, damping: 30 }} />}
                    <span className="relative block font-serif text-2xl">{m.label}</span>
                    <span className="relative mt-1 block text-xs text-mist">{m.hint}</span>
                  </button>
                ))}
              </div>
            </Reveal>

            <Reveal delay={0.4} className="mt-10">
              <p className="eyebrow mb-4">02 · Who is it for?</p>
              <div className="inline-flex rounded-full border border-white/10 p-1">
                {who.map((w) => (
                  <button key={w.value} onClick={() => setG(w.value)} className={clsx("relative rounded-full px-6 py-2.5 text-sm transition-colors duration-500", g === w.value ? "text-ink" : "text-bone/70 hover:text-bone")}>
                    {g === w.value && <motion.span layoutId="who" className="absolute inset-0 rounded-full bg-gold" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
                    <span className="relative">{w.label}</span>
                  </button>
                ))}
              </div>
            </Reveal>
          </LayoutGroup>
        </div>

        <div className="lg:col-span-7">
          <div className="grid gap-8 sm:grid-cols-3">
            <AnimatePresence mode="popLayout">
              {matches.map((p, i) => (
                <motion.div
                  key={p.slug}
                  layout
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20, transition: { duration: 0.3 } }}
                  transition={{ duration: 0.9, delay: i * 0.08, ease: EASE }}
                >
                  <ProductCard product={p} />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
