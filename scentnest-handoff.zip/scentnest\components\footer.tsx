"use client";

import Link from "next/link";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { site, whatsappLink } from "@/lib/site";
import { BottleMark } from "./logo";
import { NewsletterForm } from "./newsletter-form";

const cols = [
  { title: "Shop", links: [{ href: "/shop", label: "All fragrances" }, { href: "/shop?for=him", label: "For him" }, { href: "/shop?for=her", label: "For her" }, { href: "/shop?for=unisex", label: "Unisex" }] },
  { title: "House", links: [{ href: "/about", label: "Our story" }, { href: "/faq", label: "FAQ" }, { href: "/contact", label: "Contact" }, { href: "/policies", label: "Delivery & policies" }] },
];

export function Footer() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end end"] });
  const y = useTransform(scrollYProgress, [0, 1], ["30%", "0%"]);
  const opacity = useTransform(scrollYProgress, [0, 1], [0.2, 1]);

  return (
    <footer ref={ref} className="relative overflow-hidden border-t border-white/10 bg-ink">
      <div className="container-x grid gap-14 py-20 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="eyebrow">The inner circle</p>
          <p className="display mt-4 text-4xl sm:text-5xl">
            New scents, first.
          </p>
          <p className="mt-4 max-w-sm text-mist">Restocks, new arrivals and quiet offers. No noise, unsubscribe any time.</p>
          <NewsletterForm className="mt-8 max-w-md" />
        </div>
        <div className="grid grid-cols-2 gap-10 sm:grid-cols-3 lg:col-span-6 lg:col-start-7">
          {cols.map((c) => (
            <div key={c.title}>
              <p className="eyebrow">{c.title}</p>
              <ul className="mt-5 space-y-3">
                {c.links.map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className="link-underline text-bone/80 transition-colors hover:text-bone">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          <div>
            <p className="eyebrow">Talk to us</p>
            <ul className="mt-5 space-y-3">
              <li><a href={whatsappLink("Hi ScentNest! I have a question.")} target="_blank" rel="noopener noreferrer" className="link-underline text-bone/80 hover:text-bone">WhatsApp</a></li>
              <li><a href={site.instagram} target="_blank" rel="noopener noreferrer" className="link-underline text-bone/80 hover:text-bone">Instagram</a></li>
              <li className="text-mist">Lebanon</li>
            </ul>
          </div>
        </div>
      </div>

      <motion.div style={{ y, opacity }} className="container-x flex items-end gap-4 pb-6 sm:gap-8">
        <BottleMark className="h-[14vw] max-h-48 w-auto shrink-0 text-gold" strokeWidth={1.2} />
        <p className="display select-none text-[19vw] leading-[0.8] tracking-[-0.04em] lg:text-[17vw]">ScentNest</p>
      </motion.div>

      <div className="container-x flex flex-col gap-3 border-t border-white/10 py-6 text-xs text-mist sm:flex-row sm:items-center sm:justify-between">
        <p>© {new Date().getFullYear()} ScentNest. Bottled luxury, made in Lebanon.</p>
        <p className="max-w-xl sm:text-right">
          ScentNest fragrances are our own interpretations. Brand names are trademarks of their owners and are used only to describe scent character. We are not affiliated with them.
        </p>
      </div>
    </footer>
  );
}
