import { Button } from "@/components/button";
import { BottleMark } from "@/components/logo";

export default function NotFound() {
  return (
    <div className="container-x flex min-h-[80vh] flex-col items-center justify-center pt-24 text-center">
      <BottleMark className="h-24 w-auto text-gold" strokeWidth={1.2} />
      <p className="eyebrow mt-10">404</p>
      <h1 className="display mt-4 text-6xl sm:text-8xl">This bottle is <span className="gold-text italic">empty.</span></h1>
      <p className="mt-6 text-mist">The page you&apos;re looking for has evaporated.</p>
      <div className="mt-10"><Button href="/shop">Back to the collection</Button></div>
    </div>
  );
}
