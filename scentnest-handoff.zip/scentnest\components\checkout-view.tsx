"use client";

import Image from "next/image";
import { startTransition, useActionState, useEffect, useRef } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { placeOrder } from "@/app/actions";
import { useCart } from "@/lib/cart";
import { formatPrice, regions, site, whatsappLink } from "@/lib/site";
import { useBagLines } from "./cart-drawer";
import { Button } from "./button";
import { EASE, SplitText } from "./motion";

export function CheckoutView() {
  const { items, clear } = useCart();
  const { lines, subtotal, total } = useBagLines();
  const [state, action, pending] = useActionState(placeOrder, null);
  const snapshot = useRef<typeof lines>([]);

  useEffect(() => {
    if (state?.ok) {
      clear();
      window.scrollTo({ top: 0 });
    }
  }, [state, clear]);
  if (!state?.ok) snapshot.current = lines;

  if (state?.ok) {
    const summary = snapshot.current.map((l) => `${l.qty} × ${l.product.name} ${l.ml} ml`).join(", ");
    return <Confirmation orderNumber={state.orderNumber!} summary={summary} />;
  }

  if (lines.length === 0) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center text-center">
        <p className="display text-6xl">Your bag is empty.</p>
        <p className="mt-4 text-mist">Add a scent or two, then come back here.</p>
        <div className="mt-10"><Button href="/shop">Shop the collection</Button></div>
      </div>
    );
  }

  return (
    <div className="grid gap-16 lg:grid-cols-12">
      <form
        // Submitting through a transition keeps the fields filled if validation fails.
        onSubmit={(e) => {
          e.preventDefault();
          const data = new FormData(e.currentTarget);
          startTransition(() => action(data));
        }}
        className="lg:col-span-7"
      >
        <p className="eyebrow">Checkout</p>
        <h1 className="display mt-4 text-6xl sm:text-7xl">
          <SplitText text={"Almost *yours.*"} immediate />
        </h1>
        <p className="mt-4 max-w-md text-mist">No card needed. You pay cash when it arrives, and we call to confirm before anything ships.</p>

        <input type="hidden" name="items" value={JSON.stringify(items)} />

        <fieldset className="mt-14 grid gap-8 sm:grid-cols-2">
          <legend className="eyebrow mb-6">Your details</legend>
          <Field label="Full name" name="name" autoComplete="name" required />
          <Field label="Phone (WhatsApp)" name="phone" type="tel" autoComplete="tel" placeholder="+961 …" required />
        </fieldset>

        <fieldset className="mt-12 grid gap-8 sm:grid-cols-2">
          <legend className="eyebrow mb-6">Delivery</legend>
          <label className="block">
            <span className="text-xs text-mist">Region</span>
            <select name="region" required defaultValue="" className="field mt-1 appearance-none bg-ink">
              <option value="" disabled>Choose your region</option>
              {regions.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          </label>
          <Field label="City / town" name="city" autoComplete="address-level2" />
          <div className="sm:col-span-2">
            <Field label="Street, building, floor" name="address" autoComplete="street-address" required />
          </div>
          <div className="sm:col-span-2">
            <label className="block">
              <span className="text-xs text-mist">Notes (optional)</span>
              <textarea name="notes" rows={3} className="field mt-1 resize-none" placeholder="Landmarks, best time to call, gift message…" />
            </label>
          </div>
        </fieldset>

        <div className="mt-12 rounded-[24px] border border-white/10 p-6">
          <p className="eyebrow">Payment</p>
          <div className="mt-4 flex items-center gap-4">
            <span className="flex h-5 w-5 items-center justify-center rounded-full border border-gold"><span className="h-2.5 w-2.5 rounded-full bg-gold" /></span>
            <div>
              <p>Cash on delivery</p>
              <p className="text-sm text-mist">Pay the driver when your order arrives.</p>
            </div>
          </div>
        </div>

        <AnimatePresence>
          {state && !state.ok && (
            <motion.p initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-6 rounded-2xl border border-red-400/30 bg-red-400/5 px-5 py-4 text-sm text-red-200" role="alert">
              {state.message}
            </motion.p>
          )}
        </AnimatePresence>

        <button disabled={pending} className="mt-8 flex h-16 w-full items-center justify-center gap-3 rounded-full bg-gold text-[13px] font-medium uppercase tracking-[0.2em] text-ink transition-colors duration-500 hover:bg-gold-light disabled:opacity-60">
          {pending ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-ink/30 border-t-ink" /> : <>Place order · {formatPrice(total)} <span>→</span></>}
        </button>
      </form>

      <aside className="lg:col-span-5">
        <div className="rounded-[28px] border border-white/10 bg-ink-800 p-6 sm:p-8 lg:sticky lg:top-28">
          <p className="eyebrow">Your order</p>
          <ul className="mt-6 divide-y divide-white/10">
            {lines.map((l) => (
              <li key={`${l.slug}-${l.ml}`} className="flex items-center gap-4 py-4">
                <div className="arch-sm relative h-20 w-16 shrink-0 overflow-hidden bg-bone">
                  <Image src={l.product.image} alt="" fill sizes="64px" className="object-cover object-right mix-blend-multiply" />
                  <span className="absolute -right-0 top-0 flex h-5 min-w-5 items-center justify-center rounded-full bg-ink px-1 text-[10px]">{l.qty}</span>
                </div>
                <div className="flex-1">
                  <p className="font-serif text-lg leading-tight">{l.product.name}</p>
                  <p className="text-xs text-mist">{l.ml} ml · inspired by {l.product.inspiredBy}</p>
                </div>
                <p className="text-sm">{formatPrice(l.total)}</p>
              </li>
            ))}
          </ul>
          <div className="mt-4 space-y-2 border-t border-white/10 pt-5 text-sm">
            <div className="flex justify-between text-mist"><span>Subtotal</span><span>{formatPrice(subtotal)}</span></div>
            <div className="flex justify-between text-mist"><span>Delivery</span><span>{site.deliveryFee === 0 ? "Free" : formatPrice(site.deliveryFee)}</span></div>
            <div className="flex items-baseline justify-between pt-3"><span className="eyebrow">Total</span><span className="font-serif text-4xl">{formatPrice(total)}</span></div>
          </div>
        </div>
      </aside>
    </div>
  );
}

function Field({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-xs text-mist">{label}</span>
      <input {...props} className="field mt-1" />
    </label>
  );
}

function Confirmation({ orderNumber, summary }: { orderNumber: string; summary: string }) {
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-2xl flex-col items-center justify-center text-center">
      <svg viewBox="0 0 80 80" className="h-24 w-24 text-gold" fill="none" stroke="currentColor" strokeWidth="1.5">
        <motion.circle cx="40" cy="40" r="36" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.2, ease: EASE }} />
        <motion.path d="M26 41l9 9 19-20" strokeLinecap="round" strokeLinejoin="round" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.7, delay: 0.9, ease: EASE }} />
      </svg>
      <p className="eyebrow mt-10">Order {orderNumber}</p>
      <h1 className="display mt-4 text-6xl sm:text-7xl">
        <SplitText text={"Thank *you.*"} immediate delay={0.4} />
      </h1>
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1, duration: 1, ease: EASE }}>
        <p className="mt-6 text-lg text-mist">Your order is in. We&apos;ll call or message you shortly to confirm the details, then it&apos;s on its way. You pay when it arrives.</p>
        <div className="mt-10 flex flex-wrap justify-center gap-4">
          <Button href={whatsappLink(`Hi ScentNest! I just placed order ${orderNumber}: ${summary}.`)} external>Confirm on WhatsApp</Button>
          <Button href="/shop" variant="outline">Keep browsing</Button>
        </div>
      </motion.div>
    </div>
  );
}
