import type { Metadata } from "next";
import Image from "next/image";
import { getProducts } from "@/lib/products";
import { ImageReveal, Parallax, Reveal, SplitText } from "@/components/motion";
import { Button } from "@/components/button";
import { BottleMark } from "@/components/logo";

export const metadata: Metadata = {
  title: "Our story",
  description: "ScentNest is a Lebanese fragrance house bottling the character of the world's most iconic perfumes, at an honest price.",
};

const values = [
  { n: "01", t: "The character, kept", d: "We study what makes an iconic scent unforgettable, then build our blend around that feeling." },
  { n: "02", t: "Made to linger", d: "Generous perfume oil for a trail people notice, from the first spray to the last hour." },
  { n: "03", t: "An honest price", d: "No celebrity campaigns, no marble counters. Just the scent, beautifully bottled." },
  { n: "04", t: "Personal service", d: "Every order is confirmed by a real person. Ask us anything on WhatsApp." },
];

export default async function AboutPage() {
  const products = await getProducts();
  const a = products.find((p) => p.slug === "tabac-velours") ?? products[0];
  const b = products.find((p) => p.slug === "liquid-gold") ?? products[1];

  return (
    <>
      <section className="container-x pb-24 pt-32 sm:pt-44">
        <p className="eyebrow">Our story</p>
        <h1 className="display mt-6 max-w-6xl text-[13vw] sm:text-8xl lg:text-[132px]">
          <SplitText text={"Luxury, without\nthe *velvet rope.*"} immediate delay={0.1} />
        </h1>
      </section>

      <section className="container-x grid gap-12 pb-28 lg:grid-cols-12 lg:items-center">
        <div className="lg:col-span-6">
          <ImageReveal className="arch aspect-[4/5] bg-bone">
            <Image src={a.image} alt={a.name} fill sizes="(min-width:1024px) 50vw, 100vw" className="object-cover mix-blend-multiply" />
          </ImageReveal>
        </div>
        <div className="space-y-6 text-lg leading-relaxed text-bone/80 lg:col-span-5 lg:col-start-8">
          <Reveal>
            <p className="font-serif text-3xl leading-snug text-bone">ScentNest began with a simple question: why should a scent you love be out of reach?</p>
          </Reveal>
          <Reveal delay={0.1}>
            <p>We are a small fragrance house from Lebanon. We take the world&apos;s most loved perfumes as our starting point, and carefully bottle their character in our own blends.</p>
          </Reveal>
          <Reveal delay={0.2}>
            <p>Every bottle is filled with care, sealed by hand and confirmed personally before it leaves us. The result is the feeling of a designer fragrance, at a price that lets you wear it every day.</p>
          </Reveal>
          <Reveal delay={0.3}><Button href="/shop">Discover the collection</Button></Reveal>
        </div>
      </section>

      <section className="relative overflow-hidden border-y border-white/10 bg-bone py-28 text-ink sm:py-36">
        <Parallax offset={50} className="pointer-events-none absolute -left-10 top-0 text-ink/[0.05]">
          <BottleMark className="h-[60vh] w-auto" strokeWidth={0.6} />
        </Parallax>
        <div className="container-x relative">
          <p className="eyebrow !text-ink/50">What we stand for</p>
          <div className="mt-12 grid gap-px overflow-hidden rounded-[28px] border border-ink/10 bg-ink/10 sm:grid-cols-2">
            {values.map((v, i) => (
              <Reveal key={v.n} delay={i * 0.08} className="bg-bone p-10">
                <span className="font-serif text-5xl italic text-gold-dark">{v.n}</span>
                <p className="mt-6 font-serif text-3xl">{v.t}</p>
                <p className="mt-3 text-ink/60">{v.d}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="container-x grid gap-12 py-28 sm:py-36 lg:grid-cols-12 lg:items-center">
        <div className="lg:col-span-5">
          <p className="eyebrow">Bottled luxury</p>
          <h2 className="display mt-4 text-5xl sm:text-7xl">
            <SplitText text={"One bottle.\n*Your* signature."} />
          </h2>
          <Reveal delay={0.2}>
            <p className="mt-6 max-w-md text-mist">Our bottle is simple on purpose: clear glass, a weighty black cap and the ScentNest mark. What matters is inside.</p>
          </Reveal>
        </div>
        <div className="lg:col-span-6 lg:col-start-7">
          <ImageReveal className="arch aspect-[4/5] bg-bone">
            <Image src={b.image} alt={b.name} fill sizes="(min-width:1024px) 50vw, 100vw" className="object-cover object-right mix-blend-multiply" />
          </ImageReveal>
        </div>
      </section>
    </>
  );
}
