import type { Metadata, Viewport } from "next";
import { Bodoni_Moda, Geist } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { CartDrawer } from "@/components/cart-drawer";
import { Preloader } from "@/components/preloader";
import { getProducts } from "@/lib/products";
import { site } from "@/lib/site";

const serif = Bodoni_Moda({ subsets: ["latin"], variable: "--font-serif", style: ["normal", "italic"], display: "swap" });
const sans = Geist({ subsets: ["latin"], variable: "--font-sans", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: "ScentNest | Bottled Luxury, Inspired Fragrances in Lebanon", template: "%s | ScentNest" },
  description: site.description,
  openGraph: {
    type: "website",
    siteName: site.name,
    title: "ScentNest | Bottled Luxury",
    description: site.description,
    images: [{ url: "/og.jpg", width: 1200, height: 630, alt: "ScentNest, Bottled Luxury" }],
  },
  twitter: { card: "summary_large_image", images: ["/og.jpg"] },
};

// Re-read the catalog from Supabase at most every 5 minutes, so dashboard edits go live without a redeploy.
export const revalidate = 300;

export const viewport: Viewport = { themeColor: "#0a0a0a", colorScheme: "dark" };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const products = await getProducts();
  return (
    <html lang="en" className={`${serif.variable} ${sans.variable}`}>
      <body className="grain font-sans">
        <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[200] focus:rounded-full focus:bg-gold focus:px-4 focus:py-2 focus:text-ink">
          Skip to content
        </a>
        <Providers products={products}>
          <Preloader />
          <Header />
          <CartDrawer />
          <main id="main">{children}</main>
          <Footer />
        </Providers>
      </body>
    </html>
  );
}
