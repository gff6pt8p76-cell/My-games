export type Gender = "him" | "her" | "unisex";
export type Family = "fresh" | "floral" | "woody" | "oriental" | "gourmand" | "spicy";

export type Size = { ml: number; price: number };

export type Product = {
  slug: string;
  name: string;
  inspiredBy: string;
  house: string;
  gender: Gender;
  family: Family;
  tagline: string;
  description: string;
  notes: { top: string[]; heart: string[]; base: string[] };
  image: string;
  sizes: Size[];
  featured: boolean;
  bestseller: boolean;
  sort: number;
};

export type CartItem = { slug: string; ml: number; qty: number };
