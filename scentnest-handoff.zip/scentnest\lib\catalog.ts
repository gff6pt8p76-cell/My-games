import type { Product, Size } from "./types";

// Placeholder pricing until the owner confirms. Once Supabase is connected, edit products.sizes there.
const SIZES: Size[] = [
  { ml: 30, price: 15 },
  { ml: 50, price: 22 },
  { ml: 100, price: 35 },
];

type Seed = Omit<Product, "image" | "sizes" | "sort" | "featured" | "bestseller"> &
  Partial<Pick<Product, "featured" | "bestseller">>;

const seeds: Seed[] = [
  {
    slug: "tabac-velours", name: "Tabac Velours", inspiredBy: "Tobacco Vanille", house: "Tom Ford",
    gender: "unisex", family: "gourmand", featured: true, bestseller: true,
    tagline: "Pipe tobacco, folded into warm vanilla.",
    description: "A slow, opulent evening scent. Honeyed tobacco leaf and spice settle into a soft cloud of vanilla and cacao that lingers for hours.",
    notes: { top: ["Tobacco leaf", "Spicy notes"], heart: ["Vanilla", "Cacao", "Tonka bean"], base: ["Dried fruits", "Woody notes"] },
  },
  {
    slug: "golden-torso", name: "Golden Torso", inspiredBy: "Le Male Elixir", house: "Jean Paul Gaultier",
    gender: "him", family: "gourmand", featured: true, bestseller: true,
    tagline: "Honey, lavender and a little danger.",
    description: "Aromatic lavender and mint open onto a rich, honeyed heart. Tonka and tobacco give it the depth to carry you through the night.",
    notes: { top: ["Lavender", "Mint"], heart: ["Vanilla", "Benzoin"], base: ["Honey", "Tonka bean", "Tobacco"] },
  },
  {
    slug: "midnight-brew", name: "Midnight Brew", inspiredBy: "Black Opium", house: "Yves Saint Laurent",
    gender: "her", family: "gourmand", featured: true, bestseller: true,
    tagline: "Black coffee and white flowers after dark.",
    description: "An addictive contrast of roasted coffee and luminous white florals, wrapped in vanilla. Made for late nights and long memories.",
    notes: { top: ["Pear", "Pink pepper", "Orange blossom"], heart: ["Coffee", "Jasmine"], base: ["Vanilla", "Patchouli", "Cedar"] },
  },
  {
    slug: "blue-reverie", name: "Blue Reverie", inspiredBy: "Imagination", house: "Louis Vuitton",
    gender: "him", family: "fresh", featured: true,
    tagline: "Sparkling citrus over black tea.",
    description: "Bright citron and ginger float over a calm heart of Ceylon tea. Clean, modern and quietly expensive.",
    notes: { top: ["Citron", "Bergamot", "Ginger"], heart: ["Ceylon tea", "Cinnamon", "Neroli"], base: ["Ambroxan", "Guaiac wood", "Olibanum"] },
  },
  {
    slug: "liquid-gold", name: "Liquid Gold", inspiredBy: "J'adore", house: "Dior",
    gender: "her", family: "floral", featured: true, bestseller: true,
    tagline: "A bouquet poured in gold.",
    description: "Ripe pear and melon open onto a radiant bouquet of jasmine, rose and tuberose. Feminine, luminous, unmistakable.",
    notes: { top: ["Pear", "Melon", "Bergamot"], heart: ["Jasmine", "Rose", "Tuberose"], base: ["Musk", "Vanilla", "Cedar"] },
  },
  {
    slug: "ember", name: "Ember", inspiredBy: "Stronger With You Intensely", house: "Emporio Armani",
    gender: "him", family: "gourmand", featured: true, bestseller: true,
    tagline: "Toffee and spice by the fire.",
    description: "Pink pepper and juniper give way to caramelised toffee and cinnamon, finished with warm vanilla and amber.",
    notes: { top: ["Pink pepper", "Juniper", "Mandarin"], heart: ["Toffee", "Cinnamon", "Lavender"], base: ["Vanilla", "Tonka bean", "Amber"] },
  },
  {
    slug: "royal-oud", name: "Royal Oud", inspiredBy: "Polo Supreme Oud", house: "Ralph Lauren",
    gender: "him", family: "oriental", featured: true,
    tagline: "Smoked oud with a saffron crown.",
    description: "Dark, regal and smooth. Saffron and pepper lead into a heart of oud and incense resting on amber woods.",
    notes: { top: ["Saffron", "Black pepper"], heart: ["Oud", "Incense"], base: ["Amber", "Vetiver", "Woods"] },
  },
  {
    slug: "joie", name: "Joie", inspiredBy: "La Vie Est Belle", house: "Lancôme",
    gender: "her", family: "gourmand", featured: true,
    tagline: "Iris and praline, pure happiness.",
    description: "A sweet, joyful signature. Blackcurrant and pear open onto iris and jasmine over a gourmand base of praline and vanilla.",
    notes: { top: ["Blackcurrant", "Pear"], heart: ["Iris", "Jasmine", "Orange blossom"], base: ["Praline", "Vanilla", "Patchouli"] },
  },
  {
    slug: "rose-porcelain", name: "Rose Porcelain", inspiredBy: "Valentina", house: "Valentino",
    gender: "her", family: "floral",
    tagline: "Soft petals, polished couture.",
    description: "Delicate and modern. White truffle and bergamot meet a floral heart of jasmine and tuberose, softened by vanilla and cedar.",
    notes: { top: ["Bergamot", "White truffle"], heart: ["Jasmine", "Tuberose", "Orange blossom"], base: ["Vanilla", "Cedar", "Amber"] },
  },
  {
    slug: "stiletto-noir", name: "Stiletto Noir", inspiredBy: "Good Girl", house: "Carolina Herrera",
    gender: "her", family: "oriental", bestseller: true,
    tagline: "Light and dark, in one step.",
    description: "Bold and sensual. Almond and coffee open onto tuberose and jasmine, landing on tonka and cacao.",
    notes: { top: ["Almond", "Coffee", "Bergamot"], heart: ["Tuberose", "Jasmine"], base: ["Tonka bean", "Cacao", "Vanilla"] },
  },
  {
    slug: "ribbon", name: "Ribbon", inspiredBy: "Miss Dior", house: "Dior",
    gender: "her", family: "floral",
    tagline: "A love letter in rose.",
    description: "Fresh and tender. Iris and peony bloom into a heart of Grasse rose, finished with clean white musk.",
    notes: { top: ["Iris", "Peony", "Lily of the valley"], heart: ["Grasse rose", "Apricot"], base: ["White musk", "Vanilla"] },
  },
  {
    slug: "cassis-nuance", name: "Cassis Nuance", inspiredBy: "Sì", house: "Giorgio Armani",
    gender: "her", family: "floral",
    tagline: "Blackcurrant nectar, modern chypre.",
    description: "Elegant and self-assured. Blackcurrant nectar over rose and freesia, settling on vanilla and woody patchouli.",
    notes: { top: ["Blackcurrant"], heart: ["Rose", "Freesia"], base: ["Vanilla", "Patchouli", "Ambroxan"] },
  },
  {
    slug: "white-linen", name: "White Linen", inspiredBy: "Ana Abiyedh", house: "Lattafa",
    gender: "unisex", family: "fresh",
    tagline: "Clean skin, fresh sheets, white musk.",
    description: "Soft, powdery and impossibly clean. Bergamot and pink pepper over iris and jasmine on a bed of white musk.",
    notes: { top: ["Bergamot", "Pink pepper"], heart: ["Iris", "Jasmine"], base: ["White musk", "Amber"] },
  },
  {
    slug: "riviera-swim", name: "Riviera Swim", inspiredBy: "Afternoon Swim", house: "Louis Vuitton",
    gender: "unisex", family: "fresh",
    tagline: "A dive into citrus and sea air.",
    description: "Pure summer. A burst of mandarin, bergamot and orange with a fizz of ginger and a salty, ambergris finish.",
    notes: { top: ["Mandarin", "Bergamot"], heart: ["Orange", "Ginger"], base: ["Ambergris", "Musk"] },
  },
  {
    slug: "captains-night", name: "Captain's Night", inspiredBy: "Le Male Le Parfum", house: "Jean Paul Gaultier",
    gender: "him", family: "oriental",
    tagline: "Iris and vanilla in uniform.",
    description: "Refined and magnetic. Cardamom opens onto lavender and iris, wrapped in a smooth vanilla and woody base.",
    notes: { top: ["Cardamom"], heart: ["Lavender", "Iris"], base: ["Vanilla", "Woody notes"] },
  },
  {
    slug: "legacy", name: "Legacy", inspiredBy: "Legend", house: "Montblanc",
    gender: "him", family: "fresh",
    tagline: "The everyday gentleman.",
    description: "Fresh and easy to wear. Bergamot and lavender with a green heart of oakmoss, grounded by tonka and sandalwood.",
    notes: { top: ["Bergamot", "Lavender", "Pineapple leaf"], heart: ["Oakmoss", "Geranium"], base: ["Tonka bean", "Sandalwood"] },
  },
  {
    slug: "expedition", name: "Expedition", inspiredBy: "Explorer", house: "Montblanc",
    gender: "him", family: "woody",
    tagline: "Vetiver, leather and open roads.",
    description: "Adventurous and woody. Bergamot and pink pepper over vetiver and leather on an ambroxan and patchouli trail.",
    notes: { top: ["Bergamot", "Pink pepper", "Clary sage"], heart: ["Vetiver", "Leather"], base: ["Patchouli", "Ambroxan"] },
  },
  {
    slug: "crown", name: "Crown", inspiredBy: "Scandal Pour Homme", house: "Jean Paul Gaultier",
    gender: "him", family: "gourmand",
    tagline: "Caramel with a royal edge.",
    description: "Confident and sweet. Mandarin and clary sage meet salted caramel and tonka, balanced by vetiver.",
    notes: { top: ["Mandarin", "Clary sage"], heart: ["Caramel", "Tonka bean"], base: ["Vetiver"] },
  },
  {
    slug: "most-desired", name: "Most Desired", inspiredBy: "The Most Wanted Parfum", house: "Azzaro",
    gender: "him", family: "spicy",
    tagline: "Ginger heat, toffee smoulder.",
    description: "Intense and seductive. Fiery ginger meets a sweet toffee heart over a deep base of amber woods.",
    notes: { top: ["Ginger"], heart: ["Toffee"], base: ["Amberwood"] },
  },
  {
    slug: "detonate", name: "Detonate", inspiredBy: "Spicebomb Extreme", house: "Viktor & Rolf",
    gender: "him", family: "spicy",
    tagline: "Spice, tobacco and vanilla, at full force.",
    description: "Explosive warmth. Black pepper and cinnamon ignite a heart of saffron and lavender, finished with tobacco and vanilla.",
    notes: { top: ["Black pepper", "Grapefruit"], heart: ["Cinnamon", "Saffron", "Lavender"], base: ["Tobacco", "Vanilla"] },
  },
  {
    slug: "eden-noir", name: "Eden Noir", inspiredBy: "Le Beau Le Parfum", house: "Jean Paul Gaultier",
    gender: "him", family: "woody",
    tagline: "Coconut and iris in deep teal.",
    description: "Creamy and tropical. Pineapple and iris over a heart of coconut, with tonka and sandalwood beneath.",
    notes: { top: ["Pineapple", "Iris", "Cypress"], heart: ["Coconut"], base: ["Tonka bean", "Sandalwood", "Amber"] },
  },
  {
    slug: "paradise-verde", name: "Paradise Verde", inspiredBy: "Le Beau Paradise Garden", house: "Jean Paul Gaultier",
    gender: "him", family: "fresh",
    tagline: "A green garden after the rain.",
    description: "Lush and luminous. Green notes and water accords over fig and coconut milk, resting on sandalwood and tonka.",
    notes: { top: ["Green notes", "Water notes", "Mint"], heart: ["Fig", "Coconut"], base: ["Sandalwood", "Tonka bean"] },
  },
];

export const catalog: Product[] = seeds.map((s, i) => ({
  featured: false,
  bestseller: false,
  ...s,
  image: `/products/${s.slug}.webp`,
  sizes: SIZES,
  sort: i + 1,
}));
