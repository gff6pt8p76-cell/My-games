"use client";

import { useActionState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import clsx from "clsx";
import { subscribe } from "@/app/actions";

export function NewsletterForm({ className }: { className?: string }) {
  const [state, action, pending] = useActionState(subscribe, null);

  return (
    <form action={action} className={clsx("relative", className)}>
      <AnimatePresence mode="wait">
        {state?.ok ? (
          <motion.p key="ok" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="border-b border-gold py-3 text-gold">
            {state.message}
          </motion.p>
        ) : (
          <motion.div key="form" exit={{ opacity: 0, y: -10 }} className="flex items-center border-b border-white/15 transition-colors focus-within:border-gold">
            <label htmlFor="nl-email" className="sr-only">Email</label>
            <input id="nl-email" name="email" type="email" required placeholder="Your email" className="w-full bg-transparent py-3 text-bone placeholder:text-mist/70 focus:outline-none" />
            <button disabled={pending} className="eyebrow shrink-0 !text-bone transition-colors hover:!text-gold disabled:opacity-50">
              {pending ? "…" : "Join →"}
            </button>
          </motion.div>
        )}
      </AnimatePresence>
      {state && !state.ok && <p className="mt-2 text-sm text-red-300">{state.message}</p>}
    </form>
  );
}
