"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "framer-motion";
import { useEffect, useState } from "react";
import clsx from "clsx";
import { Logo } from "./logo";
import { useCart } from "@/lib/cart";
import { nav, site } from "@/lib/site";
import { EASE } from "./motion";
import { getLenis } from "./providers";

export function Header() {
  const { count, setOpen } = useCart();
  const pathname = usePathname();
  const { scrollY } = useScroll();
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [menu, setMenu] = useState(false);

  useMotionValueEvent(scrollY, "change", (y) => {
    const prev = scrollY.getPrevious() ?? 0;
    setScrolled(y > 40);
    setHidden(y > 400 && y > prev && !menu);
  });

  useEffect(() => setMenu(false), [pathname]);
  useEffect(() => {
    if (menu) getLenis()?.stop();
    else getLenis()?.start();
  }, [menu]);

  return (
    <>
      <motion.header
        className="fixed inset-x-0 top-0 z-50"
        animate={{ y: hidden ? "-100%" : "0%" }}
        transition={{ duration: 0.6, ease: EASE }}
      >
        <div
          className={clsx(
            "transition-[background-color,backdrop-filter,border-color] duration-700 ease-luxe border-b",
            scrolled || menu ? "border-white/10 bg-ink/70 backdrop-blur-xl" : "border-transparent bg-transparent",
          )}
        >
          <div className="container-x flex h-16 items-center justify-between sm:h-20">
            <button
              onClick={() => setMenu((m) => !m)}
              className="group flex h-10 w-10 flex-col items-start justify-center gap-[6px] lg:hidden"
              aria-label={menu ? "Close menu" : "Open menu"}
              aria-expanded={menu}
            >
              <span className={clsx("h-px w-6 bg-bone transition-transform duration-500 ease-luxe", menu && "translate-y-[3.5px] rotate-45")} />
              <span className={clsx("h-px w-4 bg-bone transition-all duration-500 ease-luxe", menu && "w-6 -translate-y-[3.5px] -rotate-45")} />
            </button>

            <nav className="hidden items-center gap-8 lg:flex" aria-label="Main">
              {nav.slice(0, 3).map((n) => (
                <Link key={n.href} href={n.href} className="link-underline text-[13px] tracking-wide text-bone/80 transition-colors hover:text-bone">
                  {n.label}
                </Link>
              ))}
            </nav>

            <Link href="/" className="group absolute left-1/2 -translate-x-1/2" aria-label={`${site.name} home`}>
              <Logo className="transition-transform duration-700 ease-luxe group-hover:-translate-y-0.5" />
            </Link>

            <div className="flex items-center gap-6">
              <nav className="hidden items-center gap-8 lg:flex" aria-label="Secondary">
                {nav.slice(3).map((n) => (
                  <Link key={n.href} href={n.href} className="link-underline text-[13px] tracking-wide text-bone/80 transition-colors hover:text-bone">
                    {n.label}
                  </Link>
                ))}
              </nav>
              <button onClick={() => setOpen(true)} className="group relative flex items-center gap-2 text-[13px] tracking-wide" aria-label={`Open bag, ${count} items`}>
                <BagIcon className="h-5 w-5 transition-transform duration-500 ease-luxe group-hover:-translate-y-0.5" />
                <span className="hidden sm:inline">Bag</span>
                <AnimatePresence mode="popLayout">
                  {count > 0 && (
                    <motion.span
                      key={count}
                      initial={{ scale: 0.4, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.4, opacity: 0 }}
                      transition={{ type: "spring", stiffness: 500, damping: 22 }}
                      className="flex h-5 min-w-5 items-center justify-center rounded-full bg-gold px-1.5 text-[11px] font-semibold text-ink"
                    >
                      {count}
                    </motion.span>
                  )}
                </AnimatePresence>
              </button>
            </div>
          </div>
        </div>
      </motion.header>

      <AnimatePresence>
        {menu && (
          <motion.div
            className="fixed inset-0 z-40 flex flex-col bg-ink pt-24 lg:hidden"
            initial={{ clipPath: "inset(0% 0% 100% 0%)" }}
            animate={{ clipPath: "inset(0% 0% 0% 0%)" }}
            exit={{ clipPath: "inset(0% 0% 100% 0%)" }}
            transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
          >
            <nav className="container-x flex flex-1 flex-col justify-center gap-2" aria-label="Mobile">
              {[{ href: "/", label: "Home" }, ...nav, { href: "/contact", label: "Contact" }].map((n, i) => (
                <div key={n.href} className="overflow-hidden">
                  <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} transition={{ duration: 0.8, delay: 0.25 + i * 0.06, ease: EASE }}>
                    <Link href={n.href} className="display flex items-baseline gap-4 py-1 text-5xl">
                      <span className="font-sans text-xs text-gold">0{i + 1}</span>
                      {n.label}
                    </Link>
                  </motion.div>
                </div>
              ))}
            </nav>
            <motion.div className="container-x flex items-center justify-between border-t border-white/10 py-6 text-sm text-mist" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }}>
              <span>Delivery across Lebanon</span>
              <a href={site.instagram} target="_blank" rel="noopener noreferrer" className="text-bone">Instagram</a>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

export function BagIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" className={className} aria-hidden="true">
      <path d="M5 8h14l-1 12H6L5 8Z" strokeLinejoin="round" />
      <path d="M9 8V6a3 3 0 0 1 6 0v2" strokeLinecap="round" />
    </svg>
  );
}
