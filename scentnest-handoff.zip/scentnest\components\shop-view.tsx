"use client";

import { AnimatePresence, LayoutGroup, motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { usePathname } from "next/navigation";
import clsx from "clsx";
import type { Family, Gender, Product } from "@/lib/types";
import { families, genders } from "@/lib/site";
import { ProductCard } from "./product-card";
import { EASE } from "./motion";

type Sort = "featured" | "price-asc" | "price-desc" | "name";

export function ShopView({ products, initialFor, initialFamily }: { products: Product[]; initialFor?: string; initialFamily?: string }) {
  const pathname = usePathname();
  const [g, setG] = useState<Gender | "all">(genders.some((x) => x.value === initialFor) ? (initialFor as Gender) : "all");
  const [fam, setFam] = useState<Family | "all">(families.some((x) => x.value === initialFamily) ? (initialFamily as Family) : "all");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<Sort>("featured");

  // Keep the URL shareable without a full navigation.
  useEffect(() => {
    const params = new URLSearchParams();
    if (g !== "all") params.set("for", g);
    if (fam !== "all") params.set("family", fam);
    const qs = params.toString();
    window.history.replaceState(null, "", qs ? `${pathname}?${qs}` : pathname);
  }, [g, fam, pathname]);

  // Header links like "For him" navigate here with new params; follow them.
  useEffect(() => {
    setG(genders.some((x) => x.value === initialFor) ? (initialFor as Gender) : "all");
    setFam(families.some((x) => x.value === initialFamily) ? (initialFamily as Family) : "all");
  }, [initialFor, initialFamily]);

  const list = useMemo(() => {
    const term = q.trim().toLowerCase();
    const min = (p: Product) => Math.min(...p.sizes.map((s) => s.price));
    return products
      .filter((p) => g === "all" || p.gender === g)
      .filter((p) => fam === "all" || p.family === fam)
      .filter((p) => !term || [p.name, p.inspiredBy, p.house, ...p.notes.top, ...p.notes.heart, ...p.notes.base].join(" ").toLowerCase().includes(term))
      .sort((a, b) => {
        if (sort === "price-asc") return min(a) - min(b);
        if (sort === "price-desc") return min(b) - min(a);
        if (sort === "name") return a.name.localeCompare(b.name);
        return Number(b.featured) - Number(a.featured) || a.sort - b.sort;
      });
  }, [products, g, fam, q, sort]);

  return (
    <>
      <div className="sticky top-16 z-30 -mx-4 mb-12 border-y border-white/10 bg-ink/80 px-4 py-4 backdrop-blur-xl sm:top-20 sm:-mx-8 sm:px-8 lg:-mx-12 lg:px-12">
        <LayoutGroup id="shop">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="-mx-1 flex gap-1 overflow-x-auto pb-1 [scrollbar-width:none]">
              {[{ value: "all" as const, label: "All" }, ...genders].map((x) => (
                <Chip key={x.value} active={g === x.value} onClick={() => setG(x.value)} id="g">
                  {x.label}
                </Chip>
              ))}
              <span className="mx-2 my-2 w-px shrink-0 bg-white/10" />
              {[{ value: "all" as const, label: "Every mood" }, ...families].map((x) => (
                <Chip key={x.value} active={fam === x.value} onClick={() => setFam(x.value)} id="f">
                  {x.label}
                </Chip>
              ))}
            </div>
            <div className="flex items-center gap-4">
              <label className="relative flex-1 lg:w-64 lg:flex-none">
                <span className="sr-only">Search</span>
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search a scent, note or brand" className="w-full rounded-full border border-white/10 bg-transparent px-5 py-2.5 text-sm placeholder:text-mist/70 focus:border-gold focus:outline-none" />
              </label>
              <label className="shrink-0">
                <span className="sr-only">Sort</span>
                <select value={sort} onChange={(e) => setSort(e.target.value as Sort)} className="rounded-full border border-white/10 bg-ink px-4 py-2.5 text-sm text-bone focus:border-gold focus:outline-none">
                  <option value="featured">Featured</option>
                  <option value="price-asc">Price, low to high</option>
                  <option value="price-desc">Price, high to low</option>
                  <option value="name">A to Z</option>
                </select>
              </label>
            </div>
          </div>
        </LayoutGroup>
      </div>

      <p className="eyebrow mb-8">{list.length} {list.length === 1 ? "fragrance" : "fragrances"}</p>

      <motion.div layout className="grid gap-x-6 gap-y-16 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        <AnimatePresence mode="popLayout">
          {list.map((p, i) => (
            <motion.div
              key={p.slug}
              layout
              initial={{ opacity: 0, y: 40, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96, transition: { duration: 0.3 } }}
              transition={{ duration: 0.8, delay: Math.min(i, 8) * 0.05, ease: EASE }}
            >
              <ProductCard product={p} priority={i < 4} />
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>

      {list.length === 0 && (
        <div className="py-24 text-center">
          <p className="display text-4xl">Nothing matches, yet.</p>
          <button onClick={() => { setG("all"); setFam("all"); setQ(""); }} className="link-underline mt-6 text-gold">Clear filters</button>
        </div>
      )}
    </>
  );
}

function Chip({ active, onClick, children, id }: { active: boolean; onClick: () => void; children: React.ReactNode; id: string }) {
  return (
    <button onClick={onClick} className={clsx("relative shrink-0 rounded-full px-4 py-2 text-sm transition-colors duration-500", active ? "text-ink" : "text-bone/70 hover:text-bone")}>
      {active && <motion.span layoutId={`chip-${id}`} className="absolute inset-0 rounded-full bg-bone" transition={{ type: "spring", stiffness: 380, damping: 32 }} />}
      <span className="relative">{children}</span>
    </button>
  );
}
