import clsx from "clsx";

export function Marquee({ items, className, reverse = false }: { items: string[]; className?: string; reverse?: boolean }) {
  const row = (
    <div className="flex shrink-0 items-center gap-10 pr-10">
      {items.map((t) => (
        <span key={t} className="flex items-center gap-10 whitespace-nowrap">
          <span>{t}</span>
          <span className="text-gold text-[0.5em]">◆</span>
        </span>
      ))}
    </div>
  );
  return (
    <div className={clsx("relative flex overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_10%,#000_90%,transparent)]", className)}>
      <div className={clsx("flex w-max animate-marquee", reverse && "[animation-direction:reverse]")}>
        {row}
        {row}
      </div>
    </div>
  );
}
