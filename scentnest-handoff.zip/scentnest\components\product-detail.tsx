"use client";

import Image from "next/image";
import { AnimatePresence, LayoutGroup, motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useRef, useState } from "react";
import clsx from "clsx";
import type { Product } from "@/lib/types";
import { useCart } from "@/lib/cart";
import { families, formatPrice, genders, whatsappLink } from "@/lib/site";
import { EASE, Reveal } from "./motion";

const sizeNote: Record<number, string> = { 30: "Try or travel", 50: "Most popular", 100: "Best value" };

export function ProductDetail({ product }: { product: Product }) {
  const { add } = useCart();
  const [ml, setMl] = useState(product.sizes.find((s) => s.ml === 50)?.ml ?? product.sizes[0].ml);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const size = product.sizes.find((s) => s.ml === ml)!;

  // Cursor-follow zoom on the image.
  const frame = useRef<HTMLDivElement>(null);
  const ox = useSpring(useMotionValue(50), { stiffness: 120, damping: 20 });
  const oy = useSpring(useMotionValue(50), { stiffness: 120, damping: 20 });
  const origin = useTransform([ox, oy], ([x, y]) => `${x}% ${y}%`);
  const [zoom, setZoom] = useState(false);

  function onMove(e: React.PointerEvent) {
    if (e.pointerType !== "mouse" || !frame.current) return;
    const r = frame.current.getBoundingClientRect();
    ox.set(((e.clientX - r.left) / r.width) * 100);
    oy.set(((e.clientY - r.top) / r.height) * 100);
  }

  function addToBag() {
    add({ slug: product.slug, ml, qty });
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  }

  const gender = genders.find((g) => g.value === product.gender)?.label;
  const family = families.find((f) => f.value === product.family)?.label;

  return (
    <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
      <div className="lg:col-span-7">
        <div className="lg:sticky lg:top-28">
          <motion.div
            ref={frame}
            onPointerMove={onMove}
            onPointerEnter={(e) => e.pointerType === "mouse" && setZoom(true)}
            onPointerLeave={() => setZoom(false)}
            className="arch relative aspect-[4/5] cursor-zoom-in overflow-hidden bg-bone"
            initial={{ clipPath: "inset(100% 0% 0% 0% round 999px 999px 28px 28px)" }}
            animate={{ clipPath: "inset(0% 0% 0% 0% round 999px 999px 28px 28px)" }}
            transition={{ duration: 1.4, ease: [0.76, 0, 0.24, 1] }}
          >
            <motion.div
              className="absolute inset-0"
              style={{ transformOrigin: origin }}
              initial={{ scale: 1.15 }}
              animate={{ scale: zoom ? 1.6 : 1 }}
              transition={{ duration: zoom ? 0.7 : 1.4, ease: EASE }}
            >
              <Image src={product.image} alt={`${product.name} by ScentNest beside ${product.inspiredBy} by ${product.house}`} fill priority sizes="(min-width:1024px) 55vw, 100vw" className="object-cover mix-blend-multiply" />
            </motion.div>
          </motion.div>
          <p className="mt-4 text-center text-xs text-mist">Shown beside the original for reference. You receive the ScentNest bottle.</p>
        </div>
      </div>

      <div className="lg:col-span-5 lg:pt-10">
        <Reveal>
          <p className="eyebrow flex items-center gap-3">
            <span className="h-px w-8 bg-gold" /> Inspired by {product.inspiredBy} · {product.house}
          </p>
        </Reveal>
        <h1 className="display mt-5 overflow-hidden text-6xl sm:text-7xl">
          <motion.span className="block" initial={{ y: "105%" }} animate={{ y: 0 }} transition={{ duration: 1.1, delay: 0.2, ease: EASE }}>
            {product.name}
          </motion.span>
        </h1>
        <Reveal delay={0.3}>
          <p className="mt-4 font-serif text-2xl italic text-bone/70">{product.tagline}</p>
          <div className="mt-6 flex flex-wrap gap-2">
            {[gender, family, "Eau de parfum"].map((t) => (
              <span key={t} className="rounded-full border border-white/10 px-3 py-1 text-xs text-mist">{t}</span>
            ))}
          </div>
          <p className="mt-8 leading-relaxed text-bone/80">{product.description}</p>
        </Reveal>

        <Reveal delay={0.4} className="mt-10 border-t border-white/10 pt-8">
          <div className="flex items-baseline justify-between">
            <p className="eyebrow">Size</p>
            <AnimatePresence mode="wait">
              <motion.p key={size.price * qty} className="font-serif text-4xl" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.35 }}>
                {formatPrice(size.price * qty)}
              </motion.p>
            </AnimatePresence>
          </div>
          <LayoutGroup id="size">
            <div className="mt-5 grid grid-cols-3 gap-3">
              {product.sizes.map((s) => (
                <button key={s.ml} onClick={() => setMl(s.ml)} className={clsx("relative rounded-2xl border px-3 py-4 text-center transition-colors duration-500", s.ml === ml ? "border-gold" : "border-white/10 hover:border-white/30")} aria-pressed={s.ml === ml}>
                  {s.ml === ml && <motion.span layoutId="size-bg" className="absolute inset-0 rounded-2xl bg-gold/10" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
                  <span className="relative block font-serif text-2xl">{s.ml} ml</span>
                  <span className="relative mt-1 block text-xs text-mist">{formatPrice(s.price)} · {sizeNote[s.ml] ?? ""}</span>
                </button>
              ))}
            </div>
          </LayoutGroup>

          <div className="mt-6 flex gap-3">
            <div className="flex h-14 items-center rounded-full border border-white/15">
              <button className="h-14 w-12 text-lg text-mist hover:text-bone" onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Decrease quantity">−</button>
              <span className="w-6 text-center tabular-nums">{qty}</span>
              <button className="h-14 w-12 text-lg text-mist hover:text-bone" onClick={() => setQty((q) => Math.min(10, q + 1))} aria-label="Increase quantity">+</button>
            </div>
            <motion.button whileTap={{ scale: 0.98 }} onClick={addToBag} className="relative flex h-14 flex-1 items-center justify-center overflow-hidden rounded-full bg-gold text-[13px] font-medium uppercase tracking-[0.18em] text-ink transition-colors duration-500 hover:bg-gold-light">
              <AnimatePresence mode="wait" initial={false}>
                <motion.span key={added ? "added" : "add"} initial={{ y: 24, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -24, opacity: 0 }} transition={{ duration: 0.35, ease: EASE }}>
                  {added ? "Added to bag ✓" : "Add to bag"}
                </motion.span>
              </AnimatePresence>
            </motion.button>
          </div>
          <a
            href={whatsappLink(`Hi ScentNest! I'd like to order ${qty} × ${product.name} (inspired by ${product.inspiredBy}), ${ml} ml.`)}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 flex h-14 items-center justify-center gap-2 rounded-full border border-white/15 text-[13px] uppercase tracking-[0.18em] transition-colors duration-500 hover:border-gold hover:text-gold"
          >
            Order on WhatsApp
          </a>
          <ul className="mt-6 grid grid-cols-3 gap-3 text-center text-xs text-mist">
            <li className="rounded-2xl border border-white/10 px-2 py-3">Cash on delivery</li>
            <li className="rounded-2xl border border-white/10 px-2 py-3">All of Lebanon</li>
            <li className="rounded-2xl border border-white/10 px-2 py-3">We call to confirm</li>
          </ul>
        </Reveal>

        <div className="mt-14">
          <p className="eyebrow">The notes</p>
          <div className="mt-6 space-y-px overflow-hidden rounded-[24px] border border-white/10 bg-white/10">
            {(["top", "heart", "base"] as const).map((k, i) => (
              <Reveal key={k} delay={i * 0.1} className="grid grid-cols-[90px_1fr] items-center gap-4 bg-ink px-6 py-5">
                <span className="text-[11px] uppercase tracking-[0.24em] text-gold">{k}</span>
                <span className="font-serif text-xl">{product.notes[k].join(", ")}</span>
              </Reveal>
            ))}
          </div>
        </div>

        <Details />
      </div>
    </div>
  );
}

function Details() {
  const [open, setOpen] = useState<number | null>(null);
  const items = [
    { t: "How to wear", d: "Spray 3 to 5 times on pulse points: neck, wrists, behind the ears. A light mist on clothing helps the scent last longer. Don't rub your wrists together." },
    { t: "Delivery & payment", d: "Delivered anywhere in Lebanon, usually within 2 to 4 business days. We call to confirm first, then you pay cash when it arrives." },
    { t: "About inspired fragrances", d: "ScentNest blends are our own interpretations of iconic scents. Brand names are used only to describe the scent's character. We are not affiliated with these brands." },
  ];
  return (
    <ul className="mt-10 divide-y divide-white/10 border-y border-white/10">
      {items.map((it, i) => (
        <li key={it.t}>
          <button onClick={() => setOpen(open === i ? null : i)} className="flex w-full items-center justify-between py-5 text-left" aria-expanded={open === i}>
            <span>{it.t}</span>
            <motion.span animate={{ rotate: open === i ? 45 : 0 }} transition={{ duration: 0.4 }} className="text-xl text-mist">+</motion.span>
          </button>
          <AnimatePresence initial={false}>
            {open === i && (
              <motion.p initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.5, ease: EASE }} className="overflow-hidden text-sm leading-relaxed text-mist">
                <span className="block pb-5">{it.d}</span>
              </motion.p>
            )}
          </AnimatePresence>
        </li>
      ))}
    </ul>
  );
}
