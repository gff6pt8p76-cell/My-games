"use client";

import { createContext, useContext, useEffect } from "react";
import Lenis from "lenis";
import { usePathname } from "next/navigation";
import { CartProvider } from "@/lib/cart";
import type { Product } from "@/lib/types";

const CatalogContext = createContext<Product[]>([]);
export const useCatalog = () => useContext(CatalogContext);

let lenis: Lenis | null = null;
export const getLenis = () => lenis;

function SmoothScroll() {
  const pathname = usePathname();

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    lenis = new Lenis({ duration: 1.15, easing: (t) => 1 - Math.pow(1 - t, 4), smoothWheel: true });
    let id = requestAnimationFrame(function raf(time) {
      lenis?.raf(time);
      id = requestAnimationFrame(raf);
    });
    return () => {
      cancelAnimationFrame(id);
      lenis?.destroy();
      lenis = null;
    };
  }, []);

  useEffect(() => {
    lenis?.scrollTo(0, { immediate: true });
  }, [pathname]);

  return null;
}

export function Providers({ products, children }: { products: Product[]; children: React.ReactNode }) {
  return (
    <CatalogContext.Provider value={products}>
      <CartProvider>
        <SmoothScroll />
        {children}
      </CartProvider>
    </CatalogContext.Provider>
  );
}
