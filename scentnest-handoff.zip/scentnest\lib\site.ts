import type { Family, Gender } from "./types";

export const site = {
  name: "ScentNest",
  tagline: "Bottled Luxury",
  description:
    "Luxury fragrances inspired by the world's most iconic perfumes. Long-lasting extrait concentration, delivered across Lebanon. Cash on delivery.",
  url: process.env.NEXT_PUBLIC_SITE_URL || "https://scentnest.vercel.app",
  whatsapp: process.env.NEXT_PUBLIC_WHATSAPP || "96100000000",
  instagram: process.env.NEXT_PUBLIC_INSTAGRAM || "https://instagram.com/scentnestlb",
  deliveryFee: 0,
  currency: "USD",
};

export const genders: { value: Gender; label: string }[] = [
  { value: "him", label: "For him" },
  { value: "her", label: "For her" },
  { value: "unisex", label: "Unisex" },
];

export const families: { value: Family; label: string }[] = [
  { value: "fresh", label: "Fresh" },
  { value: "floral", label: "Floral" },
  { value: "woody", label: "Woody" },
  { value: "oriental", label: "Oriental" },
  { value: "gourmand", label: "Gourmand" },
  { value: "spicy", label: "Spicy" },
];

export const regions = ["Beirut", "Mount Lebanon", "North", "South", "Bekaa", "Nabatieh", "Akkar", "Baalbek-Hermel"];

export const nav = [
  { href: "/shop", label: "Shop" },
  { href: "/shop?for=him", label: "For him" },
  { href: "/shop?for=her", label: "For her" },
  { href: "/about", label: "Our story" },
  { href: "/faq", label: "FAQ" },
];

export function formatPrice(n: number) {
  return `$${n.toFixed(n % 1 === 0 ? 0 : 2)}`;
}

export function whatsappLink(text: string) {
  return `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(text)}`;
}
