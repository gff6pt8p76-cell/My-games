import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { getProduct, getProducts } from "@/lib/products";
import { ProductDetail } from "@/components/product-detail";
import { ProductCard } from "@/components/product-card";
import { Reveal, SplitText } from "@/components/motion";
import { site } from "@/lib/site";

type Params = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  return (await getProducts()).map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const p = await getProduct((await params).slug);
  if (!p) return {};
  const title = `${p.name}, inspired by ${p.inspiredBy}`;
  return {
    title,
    description: `${p.tagline} ${p.description}`,
    openGraph: { title: `${title} | ScentNest`, images: [{ url: p.image }] },
  };
}

export default async function ProductPage({ params }: Params) {
  const { slug } = await params;
  const [product, all] = await Promise.all([getProduct(slug), getProducts()]);
  if (!product) notFound();

  const related = all
    .filter((p) => p.slug !== product.slug)
    .sort((a, b) => Number(b.family === product.family) - Number(a.family === product.family) || Number(b.gender === product.gender) - Number(a.gender === product.gender))
    .slice(0, 4);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: `ScentNest ${product.name}`,
    description: product.description,
    image: `${site.url}${product.image}`,
    brand: { "@type": "Brand", name: "ScentNest" },
    offers: product.sizes.map((s) => ({
      "@type": "Offer",
      name: `${s.ml} ml`,
      price: s.price,
      priceCurrency: site.currency,
      availability: "https://schema.org/InStock",
      url: `${site.url}/products/${product.slug}`,
    })),
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <div className="container-x pt-28 sm:pt-32">
        <nav className="eyebrow mb-8 flex gap-2" aria-label="Breadcrumb">
          <Link href="/shop" className="hover:text-bone">Shop</Link> <span>/</span> <span className="text-bone">{product.name}</span>
        </nav>
        <ProductDetail product={product} />
      </div>

      <section className="container-x py-28 sm:py-36">
        <div className="mb-14 flex items-end justify-between">
          <h2 className="display text-5xl sm:text-6xl">
            <SplitText text={"You may also *love.*"} />
          </h2>
          <Link href="/shop" className="link-underline hidden text-sm text-gold sm:block">Shop all →</Link>
        </div>
        <div className="grid gap-x-6 gap-y-14 sm:grid-cols-2 lg:grid-cols-4">
          {related.map((p, i) => (
            <Reveal key={p.slug} delay={i * 0.08}>
              <ProductCard product={p} />
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
