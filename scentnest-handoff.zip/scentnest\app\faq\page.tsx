import type { Metadata } from "next";
import { FaqList } from "@/components/faq-list";
import { SplitText } from "@/components/motion";
import { Button } from "@/components/button";
import { faqs } from "@/lib/faqs";
import { whatsappLink } from "@/lib/site";

export const metadata: Metadata = { title: "Questions", description: "Delivery, payment, sizes and everything else about ordering from ScentNest." };

export default function FaqPage() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
  };
  return (
    <div className="container-x pb-28 pt-32 sm:pt-44">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <div className="grid gap-16 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <p className="eyebrow">Questions</p>
          <h1 className="display mt-4 text-6xl sm:text-8xl">
            <SplitText text={"Good to\n*know.*"} immediate />
          </h1>
          <p className="mt-6 max-w-xs text-mist">Can&apos;t find your answer? We reply fast on WhatsApp.</p>
          <div className="mt-8"><Button href={whatsappLink("Hi ScentNest! I have a question.")} external variant="outline">Message us</Button></div>
        </div>
        <div className="lg:col-span-8"><FaqList /></div>
      </div>
    </div>
  );
}
