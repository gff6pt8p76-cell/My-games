import type { Metadata } from "next";
import { SplitText } from "@/components/motion";

export const metadata: Metadata = { title: "Delivery & policies", description: "Delivery, payment, returns and privacy at ScentNest." };

const sections = [
  { id: "delivery", t: "Delivery", p: ["We deliver to every region of Lebanon. Most orders arrive within 2 to 4 business days.", "After you order, we call or message you on WhatsApp to confirm your scent, size and address. Your order ships once it's confirmed."] },
  { id: "payment", t: "Payment", p: ["Cash on delivery. You pay the driver in full when your order arrives. We never ask for card details."] },
  { id: "returns", t: "Exchanges & returns", p: ["If your bottle arrives damaged or you receive the wrong scent, message us within 48 hours with a photo and we'll replace it.", "For hygiene reasons, opened fragrances can't be returned."] },
  { id: "inspired", t: "About inspired fragrances", p: ["ScentNest fragrances are our own blends, created to evoke the character of well-known perfumes. Brand and product names are trademarks of their respective owners and are used only to describe scent profiles. ScentNest is not affiliated with, endorsed by or sponsored by those brands."] },
  { id: "privacy", t: "Privacy", p: ["We only collect what we need to deliver your order: your name, phone number and address. We never sell your data.", "Your bag is stored in your own browser. We don't use advertising or tracking cookies."] },
];

export default function PoliciesPage() {
  return (
    <div className="container-x pb-28 pt-32 sm:pt-44">
      <p className="eyebrow">The fine print</p>
      <h1 className="display mt-4 text-6xl sm:text-8xl">
        <SplitText text={"Delivery &\n*policies.*"} immediate />
      </h1>
      <div className="mt-20 grid gap-16 lg:grid-cols-12">
        <nav className="hidden lg:col-span-3 lg:block">
          <ul className="sticky top-28 space-y-3 text-sm">
            {sections.map((s) => <li key={s.id}><a href={`#${s.id}`} className="link-underline text-mist hover:text-bone">{s.t}</a></li>)}
          </ul>
        </nav>
        <div className="space-y-16 lg:col-span-8 lg:col-start-5">
          {sections.map((s) => (
            <section key={s.id} id={s.id} className="scroll-mt-28 border-t border-white/10 pt-8">
              <h2 className="font-serif text-4xl">{s.t}</h2>
              {s.p.map((x) => <p key={x} className="mt-4 max-w-2xl leading-relaxed text-mist">{x}</p>)}
            </section>
          ))}
        </div>
      </div>
    </div>
  );
}
