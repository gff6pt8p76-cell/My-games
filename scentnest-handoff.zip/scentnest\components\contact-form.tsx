"use client";

import { useActionState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { sendMessage } from "@/app/actions";
import { EASE } from "./motion";

export function ContactForm() {
  const [state, action, pending] = useActionState(sendMessage, null);

  return (
    <AnimatePresence mode="wait">
      {state?.ok ? (
        <motion.div key="ok" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: EASE }} className="rounded-[28px] border border-gold/40 bg-gold/5 p-10">
          <p className="display text-4xl">Message sent.</p>
          <p className="mt-3 text-mist">{state.message}</p>
        </motion.div>
      ) : (
        <motion.form key="form" action={action} exit={{ opacity: 0, y: -10 }} className="space-y-10">
          <label className="block">
            <span className="text-xs text-mist">Your name</span>
            <input name="name" required autoComplete="name" className="field mt-1" />
          </label>
          <label className="block">
            <span className="text-xs text-mist">Phone or email</span>
            <input name="contact" required className="field mt-1" />
          </label>
          <label className="block">
            <span className="text-xs text-mist">Message</span>
            <textarea name="message" required rows={5} className="field mt-1 resize-none" placeholder="Looking for a scent like…" />
          </label>
          {state && !state.ok && <p className="text-sm text-red-300" role="alert">{state.message}</p>}
          <button disabled={pending} className="flex h-14 items-center gap-3 rounded-full bg-gold px-8 text-[13px] font-medium uppercase tracking-[0.18em] text-ink transition-colors hover:bg-gold-light disabled:opacity-60">
            {pending ? "Sending…" : "Send message →"}
          </button>
        </motion.form>
      )}
    </AnimatePresence>
  );
}
