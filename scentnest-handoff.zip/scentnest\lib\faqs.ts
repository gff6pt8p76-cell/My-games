export type QA = { q: string; a: string };

export const faqs: QA[] = [
  { q: "What does “inspired by” mean?", a: "Each ScentNest fragrance is our own interpretation of an iconic perfume's character. We name the original only so you know the scent family you're choosing. We are not affiliated with those brands." },
  { q: "How long does it last on skin?", a: "Our blends are made with a high concentration of perfume oil, so most last through the day. Like any perfume, wear time depends on your skin and the weather. Spray on pulse points and clothing for the longest trail." },
  { q: "How do I pay?", a: "Cash on delivery. You pay the driver when your order arrives, nothing up front." },
  { q: "Will you contact me before delivery?", a: "Yes. After you order, we call or message you on WhatsApp to confirm your scent, size and address before anything ships." },
  { q: "How long does delivery take?", a: "Usually 2 to 4 business days anywhere in Lebanon, depending on your region." },
  { q: "Can I change or cancel my order?", a: "Of course. Message us on WhatsApp any time before your order is out for delivery and we'll update or cancel it." },
  { q: "Which size should I choose?", a: "30 ml is perfect for trying a new scent or travelling. 50 ml is our most popular size. 100 ml is best value for a signature you wear every day." },
];
