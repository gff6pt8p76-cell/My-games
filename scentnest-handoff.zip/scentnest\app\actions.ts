"use server";

import { getProducts } from "@/lib/products";
import { serverClient } from "@/lib/supabase";
import { regions, site } from "@/lib/site";
import type { CartItem } from "@/lib/types";

export type FormState = { ok: boolean; message: string; orderNumber?: string } | null;

const clean = (v: FormDataEntryValue | null, max = 300) => String(v ?? "").trim().slice(0, max);
const phoneOk = (p: string) => /^[+\d][\d\s-]{6,18}$/.test(p);

export async function placeOrder(_: FormState, form: FormData): Promise<FormState> {
  const name = clean(form.get("name"), 120);
  const phone = clean(form.get("phone"), 30);
  const region = clean(form.get("region"), 60);
  const city = clean(form.get("city"), 120);
  const address = clean(form.get("address"), 400);
  const notes = clean(form.get("notes"), 600);
  let items: CartItem[] = [];
  try {
    items = JSON.parse(String(form.get("items") || "[]"));
  } catch {}

  if (name.length < 2) return { ok: false, message: "Please enter your full name." };
  if (!phoneOk(phone)) return { ok: false, message: "Please enter a valid phone number so we can call to confirm." };
  if (!regions.includes(region)) return { ok: false, message: "Please choose your region." };
  if (address.length < 5) return { ok: false, message: "Please add your delivery address." };
  if (!Array.isArray(items) || items.length === 0) return { ok: false, message: "Your bag is empty." };

  // Prices are always re-read on the server, never trusted from the browser.
  const products = await getProducts();
  const lines = items
    .slice(0, 30)
    .map((i) => {
      const p = products.find((x) => x.slug === i.slug);
      const size = p?.sizes.find((s) => s.ml === Number(i.ml));
      const qty = Math.max(1, Math.min(10, Math.floor(Number(i.qty) || 1)));
      return p && size ? { slug: p.slug, name: p.name, inspired_by: p.inspiredBy, ml: size.ml, unit_price: size.price, qty } : null;
    })
    .filter((l): l is NonNullable<typeof l> => l !== null);
  if (!lines.length) return { ok: false, message: "Those items are no longer available." };

  const subtotal = lines.reduce((n, l) => n + l.unit_price * l.qty, 0);
  const orderNumber = `SN-${Date.now().toString(36).toUpperCase().slice(-6)}`;

  const db = serverClient();
  if (!db) {
    console.info("[order] Supabase not configured, order not stored:", orderNumber, { name, phone, region, lines });
    return { ok: true, message: "Order received.", orderNumber };
  }

  const { error } = await db.from("orders").insert({
    order_number: orderNumber,
    customer_name: name,
    phone,
    region,
    city,
    address,
    notes,
    items: lines,
    subtotal,
    delivery_fee: site.deliveryFee,
    total: subtotal + site.deliveryFee,
    payment_method: "cod",
  });
  if (error) {
    console.error("[order] insert failed:", error.message);
    return { ok: false, message: "We couldn't place your order. Please try again or message us on WhatsApp." };
  }
  return { ok: true, message: "Order received.", orderNumber };
}

export async function subscribe(_: FormState, form: FormData): Promise<FormState> {
  const email = clean(form.get("email"), 200).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { ok: false, message: "Please enter a valid email." };
  const db = serverClient();
  if (db) {
    const { error } = await db.from("subscribers").upsert({ email }, { onConflict: "email", ignoreDuplicates: true });
    if (error) return { ok: false, message: "Something went wrong. Please try again." };
  }
  return { ok: true, message: "You're on the list." };
}

export async function sendMessage(_: FormState, form: FormData): Promise<FormState> {
  const name = clean(form.get("name"), 120);
  const contact = clean(form.get("contact"), 200);
  const message = clean(form.get("message"), 2000);
  if (name.length < 2 || contact.length < 5 || message.length < 5) return { ok: false, message: "Please fill in every field." };
  const db = serverClient();
  if (db) {
    const { error } = await db.from("contact_messages").insert({ name, contact, message });
    if (error) return { ok: false, message: "Something went wrong. Please try WhatsApp instead." };
  }
  return { ok: true, message: "Thank you. We'll get back to you within a day." };
}
