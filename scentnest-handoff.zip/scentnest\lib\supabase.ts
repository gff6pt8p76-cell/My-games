import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

export const isSupabaseConfigured = Boolean(url && anonKey);

/**
 * Server-side client. Uses the service role key when present (orders, admin reads),
 * otherwise falls back to the anon key, which is limited by the RLS policies in
 * supabase/migrations. Returns null when Supabase is not configured yet, so the
 * site keeps working on the local catalog in lib/catalog.ts.
 */
export function serverClient(): SupabaseClient | null {
  if (!url || !anonKey) return null;
  return createClient(url, serviceKey || anonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
