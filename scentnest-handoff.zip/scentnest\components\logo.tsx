import clsx from "clsx";

/** The ScentNest bottle mark, redrawn as a single-stroke SVG so it scales and animates. */
export function BottleMark({ className, strokeWidth = 2 }: { className?: string; strokeWidth?: number }) {
  return (
    <svg viewBox="0 0 40 64" fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <rect x="13" y="2" width="14" height="4" rx="1.2" />
      <path d="M16 6v8M24 6v8" />
      <path d="M11 56V23a9 9 0 0 1 9-9h0a9 9 0 0 1 9 9v33" />
      <path d="M9 56h22a2 2 0 0 1 0 4H9a2 2 0 0 1 0-4Z" />
      <path d="M14 25h12M14 53h12" />
      <path d="M14 21.5a6 6 0 0 1 3-3.5" />
    </svg>
  );
}

export function Logo({ className, withTagline = false }: { className?: string; withTagline?: boolean }) {
  return (
    <span className={clsx("inline-flex items-center gap-2.5", className)}>
      <BottleMark className="h-7 w-auto" />
      <span className="flex flex-col leading-none">
        <span className="font-serif text-[22px] tracking-[-0.01em]">ScentNest</span>
        {withTagline && <span className="mt-1 text-[8px] font-medium uppercase tracking-[0.42em] text-mist">Bottled luxury</span>}
      </span>
    </span>
  );
}
