"use client";

import { motion, useReducedMotion, useScroll, useTransform, type Variants } from "framer-motion";
import { useRef } from "react";
import clsx from "clsx";

export const EASE = [0.22, 1, 0.36, 1] as const;

/** Fades and lifts children into view once. */
export function Reveal({
  children,
  delay = 0,
  y = 28,
  className,
  as = "div",
}: {
  children: React.ReactNode;
  delay?: number;
  y?: number;
  className?: string;
  as?: "div" | "li" | "section" | "span";
}) {
  const reduce = useReducedMotion();
  const Tag = motion[as];
  return (
    <Tag
      className={className}
      initial={reduce ? false : { opacity: 0, y, filter: "blur(6px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, margin: "-10% 0px" }}
      transition={{ duration: 1.1, delay, ease: EASE }}
    >
      {children}
    </Tag>
  );
}

const lineParent: Variants = {
  hidden: {},
  show: (stagger: number) => ({ transition: { staggerChildren: stagger } }),
};
const word: Variants = {
  hidden: { y: "110%", rotate: 4 },
  show: { y: "0%", rotate: 0, transition: { duration: 1.1, ease: EASE } },
};

/**
 * Splits text into words that rise out of a mask. Wrap parts in `*asterisks*`
 * to render them in italic gold, e.g. "Bottled *luxury.*"
 */
export function SplitText({
  text,
  className,
  stagger = 0.07,
  delay = 0,
  immediate = false,
}: {
  text: string;
  className?: string;
  stagger?: number;
  delay?: number;
  immediate?: boolean;
}) {
  const reduce = useReducedMotion();
  const lines = text.split("\n");
  const viewProps = immediate
    ? { animate: "show" as const }
    : { whileInView: "show" as const, viewport: { once: true, margin: "-10% 0px" } };

  return (
    <motion.span
      className={clsx("block", className)}
      initial={reduce ? false : "hidden"}
      custom={stagger}
      variants={lineParent}
      transition={{ delayChildren: delay }}
      {...viewProps}
    >
      <span className="sr-only">{text.replace(/\*/g, "")}</span>
      {lines.map((line, li) => (
        <span key={li} className="block" aria-hidden="true">
          {tokenize(line).map((t, i) => (
            <span key={i} className="inline-block overflow-hidden pb-[0.22em] align-bottom -mb-[0.22em]">
              <motion.span
                variants={word}
                transition={{ delay: delay + (li * 3 + i) * stagger }}
                // Extra bottom padding so the gold gradient also paints the descenders.
                className={clsx("inline-block", t.accent && "gold-text italic -mb-[0.25em] pb-[0.25em] pr-[0.06em]")}
              >
                {t.text}
              </motion.span>
              {" "}
            </span>
          ))}
        </span>
      ))}
    </motion.span>
  );
}

function tokenize(line: string) {
  const out: { text: string; accent: boolean }[] = [];
  line.split(/(\*[^*]+\*)/).forEach((part) => {
    if (!part) return;
    const accent = part.startsWith("*");
    part.replace(/\*/g, "").split(" ").filter(Boolean).forEach((w) => out.push({ text: w, accent }));
  });
  return out;
}

/** Moves children on the Y axis as the element scrolls through the viewport. */
export function Parallax({ children, offset = 80, className }: { children: React.ReactNode; offset?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], reduce ? [0, 0] : [offset, -offset]);
  return (
    <motion.div ref={ref} style={{ y }} className={className}>
      {children}
    </motion.div>
  );
}

/** Image reveal: a curtain wipes up and the image settles from a slight zoom. */
export function ImageReveal({ children, className, delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={clsx("relative overflow-hidden", className)}
      initial={reduce ? false : { clipPath: "inset(100% 0% 0% 0%)" }}
      whileInView={{ clipPath: "inset(0% 0% 0% 0%)" }}
      viewport={{ once: true, margin: "-10% 0px" }}
      transition={{ duration: 1.4, delay, ease: EASE }}
    >
      <motion.div
        className="h-full w-full"
        initial={reduce ? false : { scale: 1.18 }}
        whileInView={{ scale: 1 }}
        viewport={{ once: true, margin: "-10% 0px" }}
        transition={{ duration: 1.8, delay, ease: EASE }}
      >
        {children}
      </motion.div>
    </motion.div>
  );
}
