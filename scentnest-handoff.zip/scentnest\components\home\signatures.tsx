"use client";

import Image from "next/image";
import Link from "next/link";
import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import type { Product } from "@/lib/types";
import { formatPrice } from "@/lib/site";
import { Button } from "../button";
import { SplitText } from "../motion";

/** Pinned section: vertical scroll drives a horizontal gallery of the signature scents. */
export function Signatures({ products }: { products: Product[] }) {
  const ref = useRef<HTMLElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const [distance, setDistance] = useState(0);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const x = useTransform(scrollYProgress, [0, 1], [0, -distance]);
  const progress = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);

  useEffect(() => {
    const measure = () => {
      if (!track.current) return;
      setDistance(Math.max(0, track.current.scrollWidth - window.innerWidth + 48));
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  return (
    <section ref={ref} className="relative" style={{ height: `calc(100vh + ${distance}px)` }}>
      <div className="sticky top-0 flex h-screen flex-col justify-center overflow-hidden">
        <div className="container-x mb-10 flex items-end justify-between gap-6">
          <div>
            <p className="eyebrow">The signatures</p>
            <h2 className="display mt-4 text-5xl sm:text-7xl">
              <SplitText text={"The house\n*favourites.*"} />
            </h2>
          </div>
          <div className="hidden sm:block">
            <Button href="/shop" variant="outline">View all</Button>
          </div>
        </div>

        <motion.div ref={track} style={{ x }} className="flex gap-6 pl-4 will-change-transform sm:gap-8 sm:pl-8 lg:pl-12">
          {products.map((p, i) => (
            <Link key={p.slug} href={`/products/${p.slug}`} className="group relative w-[min(72vw,44vh)] shrink-0 sm:w-[min(44vw,46vh)] lg:w-[min(25vw,46vh)]">
              <div className="arch relative aspect-[3/4] overflow-hidden bg-bone">
                <Image src={p.image} alt={`${p.name}, inspired by ${p.inspiredBy}`} fill sizes="(min-width:1024px) 25vw, 70vw" className="object-cover mix-blend-multiply transition-transform duration-[1.4s] ease-luxe group-hover:scale-105" />
                <span className="absolute left-6 top-[18%] font-serif text-6xl italic text-ink/10">{String(i + 1).padStart(2, "0")}</span>
              </div>
              <div className="mt-5 flex items-end justify-between gap-4">
                <div className="min-w-0">
                  <p className="text-[10px] uppercase tracking-[0.24em] text-mist">Inspired by {p.inspiredBy}</p>
                  <p className="mt-2 font-serif text-3xl transition-colors duration-500 group-hover:text-gold">{p.name}</p>
                  <p className="mt-1 text-sm italic text-mist">{p.tagline}</p>
                </div>
                <p className="shrink-0 whitespace-nowrap text-sm text-mist">from {formatPrice(Math.min(...p.sizes.map((s) => s.price)))}</p>
              </div>
            </Link>
          ))}
        </motion.div>

        <div className="container-x mt-10">
          <div className="h-px w-full bg-white/10">
            <motion.div className="h-px bg-gold" style={{ width: progress }} />
          </div>
        </div>
      </div>
    </section>
  );
}
