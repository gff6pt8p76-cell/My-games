import type { MetadataRoute } from "next";
import { getProducts } from "@/lib/products";
import { site } from "@/lib/site";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const products = await getProducts();
  const pages = ["", "/shop", "/about", "/faq", "/contact", "/policies"].map((p) => ({ url: `${site.url}${p}`, changeFrequency: "weekly" as const, priority: p === "" ? 1 : 0.7 }));
  return [...pages, ...products.map((p) => ({ url: `${site.url}/products/${p.slug}`, changeFrequency: "weekly" as const, priority: 0.8 }))];
}
