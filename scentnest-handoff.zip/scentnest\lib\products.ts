import "server-only";
import { cache } from "react";
import { catalog } from "./catalog";
import { serverClient } from "./supabase";
import type { Product } from "./types";

type ProductRow = {
  slug: string;
  name: string;
  inspired_by: string;
  house: string;
  gender: Product["gender"];
  family: Product["family"];
  tagline: string;
  description: string;
  notes_top: string[];
  notes_heart: string[];
  notes_base: string[];
  image_url: string;
  sizes: Product["sizes"];
  featured: boolean;
  bestseller: boolean;
  sort: number;
};

function fromRow(r: ProductRow): Product {
  return {
    slug: r.slug,
    name: r.name,
    inspiredBy: r.inspired_by,
    house: r.house,
    gender: r.gender,
    family: r.family,
    tagline: r.tagline,
    description: r.description,
    notes: { top: r.notes_top ?? [], heart: r.notes_heart ?? [], base: r.notes_base ?? [] },
    image: r.image_url,
    sizes: [...(r.sizes ?? [])].sort((a, b) => a.ml - b.ml),
    featured: r.featured,
    bestseller: r.bestseller,
    sort: r.sort,
  };
}

/** All active products. Reads Supabase when configured, otherwise the bundled catalog. */
export const getProducts = cache(async (): Promise<Product[]> => {
  const db = serverClient();
  if (!db) return catalog;
  const { data, error } = await db
    .from("products")
    .select("*")
    .eq("active", true)
    .order("sort", { ascending: true });
  if (error || !data?.length) {
    if (error) console.error("[products] falling back to local catalog:", error.message);
    return catalog;
  }
  return (data as ProductRow[]).map(fromRow);
});

export async function getProduct(slug: string) {
  const all = await getProducts();
  return all.find((p) => p.slug === slug) ?? null;
}
