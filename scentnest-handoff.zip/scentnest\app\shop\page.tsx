import type { Metadata } from "next";
import { getProducts } from "@/lib/products";
import { ShopView } from "@/components/shop-view";
import { SplitText } from "@/components/motion";

export const metadata: Metadata = {
  title: "Shop all fragrances",
  description: "Every ScentNest signature: inspired fragrances for him, for her and unisex, in 30, 50 and 100 ml. Cash on delivery across Lebanon.",
};

export default async function ShopPage({ searchParams }: { searchParams: Promise<{ for?: string; family?: string }> }) {
  const [products, sp] = await Promise.all([getProducts(), searchParams]);
  return (
    <div className="container-x pb-28 pt-32 sm:pt-40">
      <div className="mb-16 grid gap-6 lg:grid-cols-12 lg:items-end">
        <div className="lg:col-span-8">
          <p className="eyebrow">The collection · {products.length} signatures</p>
          <h1 className="display mt-4 text-6xl sm:text-8xl lg:text-[120px]">
            <SplitText text={"Every *scent.*"} immediate delay={0.1} />
          </h1>
        </div>
        <p className="max-w-sm text-mist lg:col-span-4 lg:justify-self-end">
          Iconic characters, reimagined. Filter by who it&apos;s for or by the mood you&apos;re after.
        </p>
      </div>
      <ShopView products={products} initialFor={sp.for} initialFamily={sp.family} />
    </div>
  );
}
