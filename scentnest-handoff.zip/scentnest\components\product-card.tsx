"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import clsx from "clsx";
import type { Product } from "@/lib/types";
import { formatPrice } from "@/lib/site";
import { useCart } from "@/lib/cart";

export function ProductCard({ product, index = 0, priority = false, className }: { product: Product; index?: number; priority?: boolean; className?: string }) {
  const { add } = useCart();
  const from = Math.min(...product.sizes.map((s) => s.price));
  const defaultSize = product.sizes.find((s) => s.ml === 50) ?? product.sizes[0];

  return (
    <article className={clsx("group relative", className)}>
      <Link href={`/products/${product.slug}`} className="block" aria-label={`${product.name}, inspired by ${product.inspiredBy}`}>
        <div className="arch relative aspect-[4/5] overflow-hidden bg-bone">
          <Image
            src={product.image}
            alt={`${product.name} by ScentNest next to ${product.inspiredBy} by ${product.house}`}
            fill
            priority={priority}
            sizes="(min-width: 1024px) 25vw, (min-width: 640px) 45vw, 90vw"
            className="object-cover mix-blend-multiply transition-transform duration-[1.4s] ease-luxe group-hover:scale-[1.06]"
          />
          <div className="absolute inset-x-0 bottom-0 flex translate-y-4 justify-center pb-5 opacity-0 transition-all duration-700 ease-luxe group-hover:translate-y-0 group-hover:opacity-100">
            <span className="rounded-full bg-ink/90 px-4 py-2 text-[11px] uppercase tracking-[0.2em] text-bone backdrop-blur">Discover</span>
          </div>
          {product.bestseller && (
            <span className="absolute left-1/2 top-[14%] -translate-x-1/2 rounded-full border border-ink/15 bg-bone/80 px-3 py-1 text-[10px] uppercase tracking-[0.22em] text-ink backdrop-blur">
              Bestseller
            </span>
          )}
        </div>
      </Link>
      <div className="mt-5 flex items-start justify-between gap-4">
        <div>
          <p className="eyebrow !tracking-[0.22em]">Inspired by {product.inspiredBy}</p>
          <Link href={`/products/${product.slug}`}>
            <h3 className="mt-2 font-serif text-2xl leading-none transition-colors duration-500 group-hover:text-gold">{product.name}</h3>
          </Link>
          <p className="mt-2 text-sm text-mist">from {formatPrice(from)}</p>
        </div>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => add({ slug: product.slug, ml: defaultSize.ml, qty: 1 })}
          className="mt-1 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/15 text-lg transition-colors duration-500 hover:border-gold hover:bg-gold hover:text-ink"
          aria-label={`Add ${product.name} ${defaultSize.ml} ml to bag`}
          title={`Add ${defaultSize.ml} ml`}
        >
          +
        </motion.button>
      </div>
    </article>
  );
}
