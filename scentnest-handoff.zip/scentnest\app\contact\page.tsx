import type { Metadata } from "next";
import { ContactForm } from "@/components/contact-form";
import { SplitText } from "@/components/motion";
import { site, whatsappLink } from "@/lib/site";

export const metadata: Metadata = { title: "Contact", description: "Talk to ScentNest on WhatsApp, Instagram or by message." };

export default function ContactPage() {
  return (
    <div className="container-x pb-28 pt-32 sm:pt-44">
      <div className="grid gap-16 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="eyebrow">Contact</p>
          <h1 className="display mt-4 text-6xl sm:text-8xl">
            <SplitText text={"Say\n*hello.*"} immediate />
          </h1>
          <div className="mt-12 space-y-8">
            <a href={whatsappLink("Hi ScentNest!")} target="_blank" rel="noopener noreferrer" className="group block border-t border-white/10 pt-6">
              <p className="eyebrow">WhatsApp · fastest</p>
              <p className="mt-2 font-serif text-3xl transition-colors group-hover:text-gold">+{site.whatsapp} →</p>
            </a>
            <a href={site.instagram} target="_blank" rel="noopener noreferrer" className="group block border-t border-white/10 pt-6">
              <p className="eyebrow">Instagram</p>
              <p className="mt-2 font-serif text-3xl transition-colors group-hover:text-gold">@scentnestlb →</p>
            </a>
            <div className="border-t border-white/10 pt-6">
              <p className="eyebrow">Based in</p>
              <p className="mt-2 font-serif text-3xl">Lebanon</p>
            </div>
          </div>
        </div>
        <div className="lg:col-span-6 lg:col-start-7 lg:pt-16">
          <ContactForm />
        </div>
      </div>
    </div>
  );
}
