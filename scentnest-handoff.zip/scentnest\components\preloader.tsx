"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { EASE } from "./motion";
import { getLenis } from "./providers";

const BODY = "M11 56V23a9 9 0 0 1 9-9h0a9 9 0 0 1 9 9v33";

/** First-visit intro: the bottle draws itself, fills with gold, then the curtain lifts. */
export function Preloader() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    let seen = false;
    try {
      seen = sessionStorage.getItem("sn.intro") === "1";
      sessionStorage.setItem("sn.intro", "1");
    } catch {}
    if (seen || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    setShow(true);
    document.documentElement.style.overflow = "hidden";
    getLenis()?.stop();
    const t = setTimeout(() => {
      setShow(false);
      document.documentElement.style.overflow = "";
      getLenis()?.start();
    }, 2600);
    return () => clearTimeout(t);
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          key="intro"
          className="fixed inset-0 z-[100] flex items-center justify-center bg-ink"
          exit={{ clipPath: "inset(0% 0% 100% 0%)" }}
          transition={{ duration: 1.1, ease: [0.76, 0, 0.24, 1] }}
        >
          <div className="flex flex-col items-center">
            <svg viewBox="0 0 40 64" className="h-28 w-auto text-bone" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
              <defs>
                <clipPath id="sn-body">
                  <path d={`${BODY}Z`} />
                </clipPath>
              </defs>
              <motion.rect
                x="10" width="20" clipPath="url(#sn-body)" fill="#C8A96A" stroke="none"
                initial={{ y: 56, height: 0 }}
                animate={{ y: 26, height: 30 }}
                transition={{ duration: 1.2, delay: 0.9, ease: EASE }}
                opacity={0.9}
              />
              {["M13 2h14v4H13z", "M16 6v8M24 6v8", BODY, "M9 56h22a2 2 0 0 1 0 4H9a2 2 0 0 1 0-4Z"].map((d, i) => (
                <motion.path key={i} d={d} initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.1, delay: i * 0.12, ease: EASE }} />
              ))}
            </svg>
            <div className="mt-8 overflow-hidden">
              <motion.p className="font-serif text-4xl" initial={{ y: "110%" }} animate={{ y: 0 }} transition={{ duration: 1, delay: 0.6, ease: EASE }}>
                ScentNest
              </motion.p>
            </div>
            <motion.p className="eyebrow mt-3" initial={{ opacity: 0, letterSpacing: "0.1em" }} animate={{ opacity: 1, letterSpacing: "0.42em" }} transition={{ duration: 1.4, delay: 1, ease: EASE }}>
              Bottled luxury
            </motion.p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
