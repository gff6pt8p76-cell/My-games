"use client";

import Image from "next/image";
import Link from "next/link";
import { AnimatePresence, motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import type { Product } from "@/lib/types";
import { Button } from "../button";
import { EASE, SplitText } from "../motion";
import { useCatalog } from "../providers";

export function Hero({ products }: { products: Product[] }) {
  const ref = useRef<HTMLElement>(null);
  const total = useCatalog().length;
  const [i, setI] = useState(0);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const archY = useTransform(scrollYProgress, [0, 1], ["0%", "18%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "-30%"]);
  const fade = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  useEffect(() => {
    const t = setInterval(() => setI((n) => (n + 1) % products.length), 4200);
    return () => clearInterval(t);
  }, [products.length]);

  const p = products[i];

  return (
    <section ref={ref} className="relative min-h-[100svh] overflow-hidden pt-24 sm:pt-28">
      {/* soft gold glow behind the arch */}
      <div className="pointer-events-none absolute right-[-10%] top-[10%] h-[70vh] w-[70vh] rounded-full bg-gold/10 blur-[120px]" />

      <div className="container-x relative grid min-h-[calc(100svh-7rem)] items-center gap-12 pb-16 lg:grid-cols-12">
        <motion.div style={{ y: textY, opacity: fade }} className="relative z-10 lg:col-span-7">
          <motion.p className="eyebrow flex items-center gap-3" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 1, delay: 0.3, ease: EASE }}>
            <span className="h-px w-10 bg-gold" /> Inspired fragrances · Lebanon
          </motion.p>
          <h1 className="display mt-6 text-[17vw] sm:text-[13vw] lg:text-[9.6vw] xl:text-[150px]">
            <SplitText text={"Bottled\n*luxury.*"} immediate delay={0.35} stagger={0.12} />
          </h1>
          <motion.p className="mt-8 max-w-md text-lg leading-relaxed text-bone/70" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.1, delay: 0.9, ease: EASE }}>
            The world&apos;s most iconic scents, reimagined and bottled with care. Long-lasting, beautifully made, and delivered to your door.
          </motion.p>
          <motion.div className="mt-10 flex flex-wrap items-center gap-4" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.1, delay: 1.05, ease: EASE }}>
            <Button href="/shop">Shop the collection</Button>
            <Button href="#finder" variant="outline">Find your scent</Button>
          </motion.div>
          <motion.div className="mt-14 flex gap-10 text-sm text-mist" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.2, delay: 1.3 }}>
            <div><p className="font-serif text-3xl text-bone">{total}</p><p className="mt-1">Signatures</p></div>
            <div><p className="font-serif text-3xl text-bone">COD</p><p className="mt-1">Pay on delivery</p></div>
            <div><p className="font-serif text-3xl text-bone">LB</p><p className="mt-1">Nationwide</p></div>
          </motion.div>
        </motion.div>

        <motion.div style={{ y: archY }} className="relative lg:col-span-5">
          <motion.div
            className="arch relative mx-auto aspect-[3/4] w-[78%] max-w-[460px] overflow-hidden bg-bone sm:w-[60%] lg:w-full"
            initial={{ clipPath: "inset(100% 0% 0% 0% round 999px 999px 28px 28px)" }}
            animate={{ clipPath: "inset(0% 0% 0% 0% round 999px 999px 28px 28px)" }}
            transition={{ duration: 1.6, delay: 0.2, ease: [0.76, 0, 0.24, 1] }}
          >
            <AnimatePresence mode="popLayout">
              <motion.div
                key={p.slug}
                className="absolute inset-0"
                initial={{ opacity: 0, scale: 1.12 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 1.4, ease: EASE }}
              >
                <Image src={p.image} alt={`${p.name}, inspired by ${p.inspiredBy}`} fill priority sizes="(min-width:1024px) 40vw, 80vw" className="object-cover mix-blend-multiply" />
              </motion.div>
            </AnimatePresence>
          </motion.div>

          <Link href={`/products/${p.slug}`} className="group absolute -bottom-6 left-0 right-0 mx-auto flex w-[86%] max-w-[420px] items-center justify-between gap-4 rounded-full border border-white/10 bg-ink/80 px-6 py-4 backdrop-blur-xl sm:left-auto sm:right-[-4%] sm:w-auto sm:min-w-[300px] lg:right-[-8%]">
            <AnimatePresence mode="wait">
              <motion.div key={p.slug} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.5 }}>
                <p className="text-[10px] uppercase tracking-[0.24em] text-mist">Inspired by {p.inspiredBy}</p>
                <p className="mt-1 font-serif text-xl">{p.name}</p>
              </motion.div>
            </AnimatePresence>
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gold text-ink transition-transform duration-500 group-hover:rotate-[-45deg]">→</span>
          </Link>

          <div className="absolute -left-2 top-1/2 hidden -translate-y-1/2 flex-col gap-2 lg:flex">
            {products.map((x, n) => (
              <button key={x.slug} onClick={() => setI(n)} aria-label={`Show ${x.name}`} className="group py-1">
                <span className={`block h-px transition-all duration-700 ease-luxe ${n === i ? "w-8 bg-gold" : "w-4 bg-white/25 group-hover:w-6"}`} />
              </button>
            ))}
          </div>
        </motion.div>
      </div>

      <motion.div className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-3 text-[10px] uppercase tracking-[0.3em] text-mist md:flex" style={{ opacity: fade }}>
        Scroll
        <span className="relative h-12 w-px overflow-hidden bg-white/15">
          <motion.span className="absolute inset-x-0 top-0 h-1/2 bg-gold" animate={{ y: ["-100%", "200%"] }} transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }} />
        </span>
      </motion.div>
    </section>
  );
}
