"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { EASE } from "./motion";
import { faqs, type QA } from "@/lib/faqs";

export function FaqList({ items = faqs }: { items?: QA[] }) {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <ul className="divide-y divide-white/10 border-y border-white/10">
      {items.map((f, i) => (
        <li key={f.q}>
          <button onClick={() => setOpen(open === i ? null : i)} className="group flex w-full items-center justify-between gap-6 py-7 text-left" aria-expanded={open === i}>
            <span className="font-serif text-2xl transition-colors duration-500 group-hover:text-gold sm:text-3xl">{f.q}</span>
            <span className="relative h-4 w-4 shrink-0">
              <span className="absolute left-0 top-1/2 h-px w-4 bg-bone" />
              <motion.span className="absolute left-0 top-1/2 h-px w-4 bg-bone" animate={{ rotate: open === i ? 0 : 90 }} transition={{ duration: 0.5, ease: EASE }} />
            </span>
          </button>
          <AnimatePresence initial={false}>
            {open === i && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.6, ease: EASE }} className="overflow-hidden">
                <p className="max-w-2xl pb-8 leading-relaxed text-mist">{f.a}</p>
              </motion.div>
            )}
          </AnimatePresence>
        </li>
      ))}
    </ul>
  );
}
