"use client";

import Link from "next/link";
import clsx from "clsx";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { useRef } from "react";

type Variant = "gold" | "light" | "outline" | "ghost";

const styles: Record<Variant, string> = {
  gold: "bg-gold text-ink hover:bg-gold-light",
  light: "bg-bone text-ink hover:bg-white",
  outline: "border border-white/20 text-bone hover:border-gold hover:text-gold",
  ghost: "text-bone hover:text-gold",
};

type Props = {
  children: React.ReactNode;
  variant?: Variant;
  className?: string;
  href?: string;
  external?: boolean;
  type?: "button" | "submit";
  disabled?: boolean;
  onClick?: () => void;
  magnetic?: boolean;
};

/** Pill button with a soft magnetic pull and a sliding arrow. */
export function Button({ children, variant = "gold", className, href, external, type = "button", disabled, onClick, magnetic = true }: Props) {
  const ref = useRef<HTMLSpanElement>(null);
  const x = useSpring(useMotionValue(0), { stiffness: 220, damping: 18, mass: 0.4 });
  const y = useSpring(useMotionValue(0), { stiffness: 220, damping: 18, mass: 0.4 });

  function move(e: React.PointerEvent) {
    if (!magnetic || e.pointerType !== "mouse" || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    x.set((e.clientX - r.left - r.width / 2) * 0.18);
    y.set((e.clientY - r.top - r.height / 2) * 0.3);
  }
  function leave() {
    x.set(0);
    y.set(0);
  }

  const cls = clsx(
    "group relative inline-flex h-12 items-center justify-center gap-3 overflow-hidden rounded-full px-7 text-[13px] font-medium uppercase tracking-[0.18em] transition-colors duration-500 ease-luxe",
    styles[variant],
    disabled && "cursor-not-allowed opacity-50",
    className,
  );

  const inner = (
    <motion.span ref={ref} style={{ x, y }} onPointerMove={move} onPointerLeave={leave} className="inline-flex">
      <span className={cls}>
        <span className="relative z-10">{children}</span>
        <span className="relative z-10 inline-block transition-transform duration-500 ease-luxe group-hover:translate-x-1">→</span>
      </span>
    </motion.span>
  );

  if (href) {
    return external ? (
      <a href={href} target="_blank" rel="noopener noreferrer" className="inline-flex">
        {inner}
      </a>
    ) : (
      <Link href={href} className="inline-flex" onClick={onClick}>
        {inner}
      </Link>
    );
  }
  return (
    <button type={type} disabled={disabled} onClick={onClick} className="inline-flex disabled:pointer-events-none">
      {inner}
    </button>
  );
}
