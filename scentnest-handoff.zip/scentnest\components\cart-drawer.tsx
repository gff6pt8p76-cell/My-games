"use client";

import Image from "next/image";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { useEffect } from "react";
import { useCart } from "@/lib/cart";
import { formatPrice, site } from "@/lib/site";
import { useCatalog, getLenis } from "./providers";
import { Button } from "./button";
import { EASE } from "./motion";

export function useBagLines() {
  const { items } = useCart();
  const catalog = useCatalog();
  const lines = items
    .map((i) => {
      const p = catalog.find((c) => c.slug === i.slug);
      const size = p?.sizes.find((s) => s.ml === i.ml);
      return p && size ? { ...i, product: p, price: size.price, total: size.price * i.qty } : null;
    })
    .filter((l): l is NonNullable<typeof l> => l !== null);
  const subtotal = lines.reduce((n, l) => n + l.total, 0);
  return { lines, subtotal, total: subtotal + site.deliveryFee };
}

export function CartDrawer() {
  const { open, setOpen, update, remove } = useCart();
  const { lines, subtotal } = useBagLines();

  useEffect(() => {
    if (open) getLenis()?.stop();
    else getLenis()?.start();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, setOpen]);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            className="fixed inset-0 z-[70] bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            onClick={() => setOpen(false)}
          />
          <motion.aside
            role="dialog"
            aria-label="Your bag"
            className="fixed inset-y-0 right-0 z-[80] flex w-full max-w-[460px] flex-col border-l border-white/10 bg-ink-800"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
            data-lenis-prevent
          >
            <div className="flex items-center justify-between border-b border-white/10 px-6 py-6">
              <p className="font-serif text-2xl">
                Your bag <span className="font-sans text-sm text-mist">({lines.length})</span>
              </p>
              <button onClick={() => setOpen(false)} className="eyebrow transition-colors hover:text-bone" aria-label="Close bag">
                Close
              </button>
            </div>

            {lines.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-6 px-8 text-center">
                <p className="display text-4xl">Your bag is empty.</p>
                <p className="text-mist">Find a signature that feels like yours.</p>
                <Button href="/shop" onClick={() => setOpen(false)}>
                  Shop the collection
                </Button>
              </div>
            ) : (
              <>
                <ul className="flex-1 divide-y divide-white/10 overflow-y-auto px-6">
                  <AnimatePresence initial={false}>
                    {lines.map((l, i) => (
                      <motion.li
                        key={`${l.slug}-${l.ml}`}
                        layout
                        initial={{ opacity: 0, x: 40 }}
                        animate={{ opacity: 1, x: 0, transition: { delay: 0.25 + i * 0.06, duration: 0.7, ease: EASE } }}
                        exit={{ opacity: 0, x: 40, transition: { duration: 0.4 } }}
                        className="flex gap-4 py-5"
                      >
                        <Link href={`/products/${l.slug}`} onClick={() => setOpen(false)} className="arch-sm relative h-28 w-20 shrink-0 overflow-hidden bg-bone">
                          <Image src={l.product.image} alt={l.product.name} fill sizes="80px" className="object-cover object-right mix-blend-multiply" />
                        </Link>
                        <div className="flex flex-1 flex-col">
                          <div className="flex justify-between gap-3">
                            <div>
                              <p className="font-serif text-xl leading-tight">{l.product.name}</p>
                              <p className="mt-1 text-xs text-mist">Inspired by {l.product.inspiredBy} · {l.ml} ml</p>
                            </div>
                            <p className="text-sm">{formatPrice(l.total)}</p>
                          </div>
                          <div className="mt-auto flex items-center justify-between pt-3">
                            <div className="flex items-center rounded-full border border-white/15">
                              <button className="h-8 w-8 text-mist hover:text-bone" onClick={() => update(l.slug, l.ml, l.qty - 1)} aria-label="Decrease">−</button>
                              <span className="w-6 text-center text-sm tabular-nums">{l.qty}</span>
                              <button className="h-8 w-8 text-mist hover:text-bone" onClick={() => update(l.slug, l.ml, l.qty + 1)} aria-label="Increase">+</button>
                            </div>
                            <button className="text-xs text-mist underline-offset-4 hover:text-bone hover:underline" onClick={() => remove(l.slug, l.ml)}>
                              Remove
                            </button>
                          </div>
                        </div>
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </ul>
                <div className="space-y-4 border-t border-white/10 px-6 py-6">
                  <div className="flex justify-between text-sm text-mist">
                    <span>Delivery</span>
                    <span>{site.deliveryFee === 0 ? "Free" : formatPrice(site.deliveryFee)}</span>
                  </div>
                  <div className="flex items-baseline justify-between">
                    <span className="eyebrow">Subtotal</span>
                    <span className="font-serif text-3xl">{formatPrice(subtotal)}</span>
                  </div>
                  <Link href="/checkout" onClick={() => setOpen(false)} className="block">
                    <span className="flex h-14 w-full items-center justify-center gap-3 rounded-full bg-gold text-[13px] font-medium uppercase tracking-[0.18em] text-ink transition-colors duration-500 hover:bg-gold-light">
                      Checkout <span>→</span>
                    </span>
                  </Link>
                  <p className="text-center text-xs text-mist">Pay cash when it arrives. We call to confirm first.</p>
                </div>
              </>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
