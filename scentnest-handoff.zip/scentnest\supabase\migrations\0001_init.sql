-- ScentNest schema. Run in Supabase → SQL Editor (or `supabase db push`), then run seed.sql.

-- Products -------------------------------------------------------------------
create table if not exists public.products (
  id           uuid primary key default gen_random_uuid(),
  slug         text unique not null,
  name         text not null,
  inspired_by  text not null,
  house        text not null,
  gender       text not null check (gender in ('him', 'her', 'unisex')),
  family       text not null check (family in ('fresh', 'floral', 'woody', 'oriental', 'gourmand', 'spicy')),
  tagline      text not null default '',
  description  text not null default '',
  notes_top    text[] not null default '{}',
  notes_heart  text[] not null default '{}',
  notes_base   text[] not null default '{}',
  -- Path in /public (e.g. /products/joie.webp) or a full Supabase Storage URL.
  image_url    text not null,
  -- [{ "ml": 50, "price": 22 }, ...] — prices in USD.
  sizes        jsonb not null default '[]',
  featured     boolean not null default false,
  bestseller   boolean not null default false,
  active       boolean not null default true,
  sort         int not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

-- Orders (cash on delivery) ----------------------------------------------------
create table if not exists public.orders (
  id              uuid primary key default gen_random_uuid(),
  order_number    text unique not null,
  status          text not null default 'pending'
                  check (status in ('pending', 'confirmed', 'out_for_delivery', 'delivered', 'cancelled')),
  customer_name   text not null,
  phone           text not null,
  region          text not null,
  city            text,
  address         text not null,
  notes           text,
  items           jsonb not null,  -- [{ slug, name, inspired_by, ml, unit_price, qty }]
  subtotal        numeric(10,2) not null,
  delivery_fee    numeric(10,2) not null default 0,
  total           numeric(10,2) not null,
  payment_method  text not null default 'cod',
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists orders_created_at_idx on public.orders (created_at desc);
create index if not exists orders_status_idx on public.orders (status);

-- Newsletter & contact ---------------------------------------------------------
create table if not exists public.subscribers (
  id          uuid primary key default gen_random_uuid(),
  email       text unique not null,
  created_at  timestamptz not null default now()
);

create table if not exists public.contact_messages (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  contact     text not null,
  message     text not null,
  handled     boolean not null default false,
  created_at  timestamptz not null default now()
);

-- updated_at trigger -------------------------------------------------------------
create or replace function public.touch_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists products_touch on public.products;
create trigger products_touch before update on public.products for each row execute function public.touch_updated_at();
drop trigger if exists orders_touch on public.orders;
create trigger orders_touch before update on public.orders for each row execute function public.touch_updated_at();

-- Row level security ---------------------------------------------------------------
-- The website writes orders/messages from the server with the service role key,
-- which bypasses RLS. These policies only govern the public anon key.
alter table public.products          enable row level security;
alter table public.orders            enable row level security;
alter table public.subscribers       enable row level security;
alter table public.contact_messages  enable row level security;

drop policy if exists "Public can read active products" on public.products;
create policy "Public can read active products" on public.products
  for select to anon, authenticated using (active = true);

-- Fallback if the service role key is not set: anon may insert, never read.
drop policy if exists "Anyone can place an order" on public.orders;
create policy "Anyone can place an order" on public.orders
  for insert to anon with check (status = 'pending' and payment_method = 'cod');

drop policy if exists "Anyone can subscribe" on public.subscribers;
create policy "Anyone can subscribe" on public.subscribers
  for insert to anon with check (true);

drop policy if exists "Anyone can send a message" on public.contact_messages;
create policy "Anyone can send a message" on public.contact_messages
  for insert to anon with check (true);
